import { cn } from "@/lib/utils";

interface SectionHeadingProps {
  title: string;
  subtitle?: string;
  centered?: boolean;
  className?: string;
}

export default function SectionHeading({
  title,
  subtitle,
  centered = true,
  className,
}: SectionHeadingProps) {
  return (
    <div 
      className={cn(
        "max-w-3xl mb-12",
        centered ? "mx-auto text-center" : "text-left",
        className
      )}
    >
      <h2 className="text-3xl md:text-4xl font-bold mb-4 tracking-tight">{title}</h2>
      {subtitle && (
        <p className="text-muted-foreground text-lg">{subtitle}</p>
      )}
    </div>
  );
}