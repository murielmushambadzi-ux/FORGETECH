import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";

const navLinks = [
  { name: "Home", path: "/" },
  { name: "About", path: "/about" },
  {
    name: "Services",
    path: "/services",
    subMenu: [
      { name: "Wedding Photography", path: "/services/wedding" },
      { name: "Event Coverage", path: "/services/events" },
      { name: "Portrait Sessions", path: "/services/portraits" },
      { name: "Commercial Shoots", path: "/services/commercial" },
    ],
  },
  { name: "Portfolio", path: "/portfolio" },
  { name: "Pricing", path: "/pricing" },
  { name: "Gallery", path: "/gallery" },
  { name: "Blog", path: "/blog" },
  { name: "Testimonials", path: "/testimonials" },
  { name: "Contact", path: "/contact" },
];

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { pathname } = useLocation();
  
  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 20;
      setScrolled(isScrolled);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close mobile menu when changing routes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [pathname]);

  return (
    <header
      className={cn(
        "fixed top-0 w-full z-50 transition-all duration-300",
        scrolled ? "bg-background/95 backdrop-blur-md shadow-sm" : "bg-transparent"
      )}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center">
            <span className="text-2xl font-bold text-primary tracking-tight">MUZALA</span>
            <span className="text-2xl font-light text-secondary">CREATIVE</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:block">
            <NavigationMenu>
              <NavigationMenuList>
                {navLinks.map((link) => {
                  if (link.subMenu) {
                    return (
                      <NavigationMenuItem key={link.name}>
                        <NavigationMenuTrigger>{link.name}</NavigationMenuTrigger>
                        <NavigationMenuContent>
                          <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2">
                            {link.subMenu.map((subLink) => (
                              <li key={subLink.name}>
                                <NavigationMenuLink asChild>
                                  <Link
                                    to={subLink.path}
                                    className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                                  >
                                    <div className="text-sm font-medium leading-none">{subLink.name}</div>
                                  </Link>
                                </NavigationMenuLink>
                              </li>
                            ))}
                          </ul>
                        </NavigationMenuContent>
                      </NavigationMenuItem>
                    );
                  } else {
                    return (
                      <NavigationMenuItem key={link.name}>
                        <Link
                          to={link.path}
                          className={cn(
                            "block px-4 py-2 text-sm font-medium transition-colors hover:text-primary",
                            pathname === link.path ? "text-primary" : "text-foreground"
                          )}
                        >
                          {link.name}
                        </Link>
                      </NavigationMenuItem>
                    );
                  }
                })}
              </NavigationMenuList>
            </NavigationMenu>
          </div>

          <div className="hidden lg:block">
            <Button>Book a Session</Button>
          </div>

          {/* Mobile Navigation */}
          <div className="lg:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Toggle Menu"
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden pt-4 pb-2">
            <div className="space-y-1">
              {navLinks.map((link) => {
                if (link.subMenu) {
                  return (
                    <div key={link.name} className="collapse-menu">
                      <details>
                        <summary className="flex justify-between items-center px-4 py-2 text-base font-medium cursor-pointer">
                          {link.name}
                          <ChevronDown className="h-4 w-4" />
                        </summary>
                        <div className="pl-4">
                          {link.subMenu.map((subLink) => (
                            <Link
                              key={subLink.name}
                              to={subLink.path}
                              className={cn(
                                "block px-4 py-2 text-sm",
                                pathname === subLink.path ? "text-primary font-medium" : "text-muted-foreground"
                              )}
                            >
                              {subLink.name}
                            </Link>
                          ))}
                        </div>
                      </details>
                    </div>
                  );
                } else {
                  return (
                    <Link
                      key={link.name}
                      to={link.path}
                      className={cn(
                        "block px-4 py-2 text-base font-medium",
                        pathname === link.path ? "text-primary" : "text-foreground"
                      )}
                    >
                      {link.name}
                    </Link>
                  );
                }
              })}
              <div className="pt-4">
                <Button className="w-full">Book a Session</Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}