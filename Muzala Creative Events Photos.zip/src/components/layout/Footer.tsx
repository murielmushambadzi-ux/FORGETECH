import { Link } from "react-router-dom";
import { Instagram, Facebook, Twitter, Mail, Phone, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";

export default function Footer() {
  return (
    <footer className="bg-secondary text-secondary-foreground">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand section */}
          <div className="space-y-4">
            <Link to="/" className="inline-block">
              <span className="text-3xl font-bold text-primary">MUZALA</span>
              <span className="text-3xl font-light text-secondary-foreground block">CREATIVE</span>
            </Link>
            <p className="text-sm text-secondary-foreground/80">
              Capturing life's most beautiful moments with artistic vision and professional excellence.
            </p>
            <div className="flex space-x-4">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
                <Instagram size={20} />
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
                <Facebook size={20} />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Quick Links</h3>
            <div className="grid grid-cols-2 gap-2">
              <Link to="/" className="text-sm hover:text-primary transition-colors">Home</Link>
              <Link to="/about" className="text-sm hover:text-primary transition-colors">About</Link>
              <Link to="/services" className="text-sm hover:text-primary transition-colors">Services</Link>
              <Link to="/portfolio" className="text-sm hover:text-primary transition-colors">Portfolio</Link>
              <Link to="/pricing" className="text-sm hover:text-primary transition-colors">Pricing</Link>
              <Link to="/gallery" className="text-sm hover:text-primary transition-colors">Gallery</Link>
              <Link to="/blog" className="text-sm hover:text-primary transition-colors">Blog</Link>
              <Link to="/testimonials" className="text-sm hover:text-primary transition-colors">Testimonials</Link>
              <Link to="/contact" className="text-sm hover:text-primary transition-colors">Contact</Link>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Contact Us</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <MapPin size={18} />
                <span className="text-sm">123 Photography Lane, Creative City</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone size={18} />
                <span className="text-sm">+1 (234) 567-8900</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail size={18} />
                <span className="text-sm">info@muzalacreative.com</span>
              </div>
            </div>
          </div>

          {/* Newsletter */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Newsletter</h3>
            <p className="text-sm text-secondary-foreground/80">
              Subscribe to get updates on our latest work and special promotions.
            </p>
            <form className="space-y-2">
              <Input 
                type="email" 
                placeholder="Your email address" 
                className="bg-secondary-foreground/10 border-secondary-foreground/20"
              />
              <Button type="submit" className="w-full">Subscribe</Button>
            </form>
          </div>
        </div>
        
        <Separator className="my-8 bg-secondary-foreground/20" />
        
        <div className="flex flex-col md:flex-row items-center justify-between text-sm text-secondary-foreground/70">
          <p>© {new Date().getFullYear()} MUZALA CREATIVE. All rights reserved.</p>
          <div className="flex space-x-4 mt-2 md:mt-0">
            <Link to="/privacy-policy" className="hover:text-primary transition-colors">Privacy Policy</Link>
            <Link to="/terms-of-service" className="hover:text-primary transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}