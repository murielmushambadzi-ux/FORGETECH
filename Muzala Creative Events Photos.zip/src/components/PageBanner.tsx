import { cn } from "@/lib/utils";

interface PageBannerProps {
  title: string;
  backgroundImage: string;
  subtitle?: string;
  className?: string;
}

export default function PageBanner({
  title,
  backgroundImage,
  subtitle,
  className,
}: PageBannerProps) {
  return (
    <div
      className={cn(
        "relative h-64 md:h-80 w-full bg-cover bg-center bg-no-repeat flex items-center justify-center",
        className
      )}
      style={{ backgroundImage: `url(${backgroundImage})` }}
    >
      <div className="absolute inset-0 bg-black/50"></div>
      <div className="relative z-10 text-center text-white">
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-2">{title}</h1>
        {subtitle && <p className="text-lg text-white/90 max-w-xl mx-auto">{subtitle}</p>}
      </div>
    </div>
  );
}