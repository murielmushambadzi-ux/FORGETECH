import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ServiceCardProps {
  title: string;
  description: string;
  icon?: React.ReactNode;
  image?: string;
  link: string;
  className?: string;
  imagePosition?: "top" | "background";
  hoverEffect?: boolean;
}

export default function ServiceCard({
  title,
  description,
  icon,
  image,
  link,
  className,
  imagePosition = "top",
  hoverEffect = true,
}: ServiceCardProps) {
  if (imagePosition === "background" && image) {
    return (
      <div 
        className={cn(
          "relative h-[400px] overflow-hidden rounded-lg group",
          hoverEffect && "cursor-pointer transition-transform hover:scale-[1.02]",
          className
        )}
      >
        <div 
          className="absolute inset-0 bg-cover bg-center transition-transform duration-700"
          style={{ backgroundImage: `url(${image})` }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/60 to-black/20"></div>
        <div className="absolute inset-0 flex flex-col justify-end p-6 text-white">
          <h3 className="text-2xl font-semibold mb-2">{title}</h3>
          <p className="text-sm text-white/80 mb-4">{description}</p>
          <Button 
            asChild
            variant="outline" 
            className="border-white text-white hover:bg-white hover:text-black w-fit"
          >
            <Link to={link}>
              Learn More
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <Card 
      className={cn(
        "overflow-hidden h-full flex flex-col",
        hoverEffect && "transition-transform hover:scale-[1.02]",
        className
      )}
    >
      {image && imagePosition === "top" && (
        <div className="aspect-video w-full overflow-hidden">
          <img 
            src={image}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
        </div>
      )}
      <CardContent className="flex-grow p-6">
        {icon && <div className="mb-4 text-primary">{icon}</div>}
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-muted-foreground">{description}</p>
      </CardContent>
      <CardFooter className="p-6 pt-0">
        <Button asChild variant="ghost" className="px-0 hover:bg-transparent hover:text-primary">
          <Link to={link}>
            Learn More
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
}