import { useState } from "react";
import { cn } from "@/lib/utils";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Image {
  id: number;
  url: string;
  alt: string;
  width?: number;
  height?: number;
}

interface ImageGalleryProps {
  images: Image[];
  columns?: number;
  gap?: number;
  className?: string;
}

export default function ImageGallery({
  images,
  columns = 3,
  gap = 4,
  className,
}: ImageGalleryProps) {
  const [selectedImage, setSelectedImage] = useState<Image | null>(null);

  const columnClasses = {
    1: "grid-cols-1",
    2: "grid-cols-1 md:grid-cols-2",
    3: "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3",
    4: "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4",
    5: "grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5",
  }[columns] || "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3";

  const gapClasses = {
    0: "gap-0",
    1: "gap-1",
    2: "gap-2",
    3: "gap-3",
    4: "gap-4",
    5: "gap-5",
    6: "gap-6",
    8: "gap-8",
  }[gap] || "gap-4";

  return (
    <>
      <div
        className={cn(
          `grid ${columnClasses} ${gapClasses}`,
          className
        )}
      >
        {images.map((image) => (
          <div
            key={image.id}
            className="group relative aspect-[4/3] overflow-hidden rounded-md cursor-pointer transition-transform hover:scale-[1.02] bg-muted"
            onClick={() => setSelectedImage(image)}
          >
            <img
              src={image.url}
              alt={image.alt}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
              width={image.width || 600}
              height={image.height || 400}
              loading="lazy"
            />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <span className="text-white text-sm font-medium">{image.alt}</span>
            </div>
          </div>
        ))}
      </div>
      
      {/* Lightbox */}
      {selectedImage && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4"
          onClick={() => setSelectedImage(null)}
        >
          <div className="relative max-w-5xl max-h-[90vh] w-full" onClick={e => e.stopPropagation()}>
            <img
              src={selectedImage.url}
              alt={selectedImage.alt}
              className="w-full h-auto max-h-[90vh] object-contain"
            />
            <Button 
              size="icon"
              variant="ghost" 
              onClick={() => setSelectedImage(null)}
              className="absolute top-2 right-2 text-white bg-black/50 hover:bg-black/70 rounded-full"
            >
              <X className="w-5 h-5" />
            </Button>
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/50 text-white text-center">
              {selectedImage.alt}
            </div>
          </div>
        </div>
      )}
    </>
  );
}