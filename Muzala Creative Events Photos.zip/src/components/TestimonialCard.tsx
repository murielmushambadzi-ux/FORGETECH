import { Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";

interface TestimonialCardProps {
  name: string;
  role?: string;
  quote: string;
  rating?: number;
  image?: string;
  className?: string;
}

export default function TestimonialCard({
  name,
  role,
  quote,
  rating = 5,
  image,
  className,
}: TestimonialCardProps) {
  return (
    <Card className={cn("h-full", className)}>
      <CardContent className="p-6 flex flex-col h-full">
        <div className="flex items-center gap-1 mb-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star
              key={i}
              size={16}
              className={i < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}
            />
          ))}
        </div>
        
        <blockquote className="flex-grow">
          <p className="text-muted-foreground leading-relaxed mb-4">"{quote}"</p>
        </blockquote>
        
        <div className="flex items-center mt-4 pt-4 border-t border-border">
          {image && (
            <div className="mr-3">
              <div className="w-10 h-10 rounded-full overflow-hidden">
                <img 
                  src={image} 
                  alt={name} 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          )}
          <div>
            <div className="font-medium">{name}</div>
            {role && <div className="text-sm text-muted-foreground">{role}</div>}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}