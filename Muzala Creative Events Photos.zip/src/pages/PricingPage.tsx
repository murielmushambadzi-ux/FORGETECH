import { useState } from "react";
import { Link } from "react-router-dom";
import { CheckCircle, Package, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import PageBanner from "@/components/PageBanner";
import SectionHeading from "@/components/SectionHeading";

// Pricing packages by category
const pricingPackages = {
  weddings: [
    {
      id: "wedding-essential",
      name: "Essential",
      price: "$2,500",
      description: "Perfect for intimate weddings and elopements",
      popular: false,
      features: [
        "6 hours of coverage",
        "1 photographer",
        "300+ edited digital images",
        "Online gallery",
        "Print release",
        "Engagement session"
      ],
    },
    {
      id: "wedding-premium",
      name: "Premium",
      price: "$3,800",
      description: "Our most popular package for medium to large weddings",
      popular: true,
      features: [
        "10 hours of coverage",
        "2 photographers",
        "600+ edited digital images",
        "Online gallery",
        "Print release",
        "Engagement session",
        "Wedding album (10x10, 20 pages)",
        "Second day coverage (rehearsal dinner)"
      ],
    },
    {
      id: "wedding-luxury",
      name: "Luxury",
      price: "$5,500",
      description: "The ultimate wedding photography experience",
      popular: false,
      features: [
        "Full day coverage (up to 12 hours)",
        "2 photographers",
        "800+ edited digital images",
        "Online gallery",
        "Print release",
        "Engagement session",
        "Deluxe wedding album (12x12, 30 pages)",
        "Two parent albums (8x8, 20 pages)",
        "Second day coverage (rehearsal dinner)",
        "Drone aerial photography",
        "Same-day highlight slideshow"
      ],
    }
  ],
  events: [
    {
      id: "events-basic",
      name: "Basic Event",
      price: "$1,200",
      description: "Perfect for small events up to 3 hours",
      popular: false,
      features: [
        "3 hours of coverage",
        "1 photographer",
        "150+ edited digital images",
        "Online gallery",
        "Commercial usage rights",
        "48-hour rush delivery available (+$300)"
      ],
    },
    {
      id: "events-standard",
      name: "Standard Event",
      price: "$2,200",
      description: "Our most popular package for medium-sized events",
      popular: true,
      features: [
        "6 hours of coverage",
        "1 photographer",
        "300+ edited digital images",
        "Online gallery",
        "Commercial usage rights",
        "Social media highlight set",
        "48-hour rush delivery available (+$300)"
      ],
    },
    {
      id: "events-premium",
      name: "Premium Event",
      price: "$3,500",
      description: "Comprehensive coverage for large events",
      popular: false,
      features: [
        "Full day coverage (up to 10 hours)",
        "2 photographers",
        "500+ edited digital images",
        "Online gallery",
        "Commercial usage rights",
        "Social media highlight set",
        "Same-day social media previews",
        "Custom USB drive with all images",
        "24-hour rush delivery available (+$500)"
      ],
    }
  ],
  portraits: [
    {
      id: "portraits-mini",
      name: "Mini Session",
      price: "$350",
      description: "Quick session for individual portraits or headshots",
      popular: false,
      features: [
        "30-minute session",
        "1 location",
        "1 outfit change",
        "15 edited digital images",
        "Online gallery",
        "Personal use rights",
        "Quick turnaround (1 week)"
      ],
    },
    {
      id: "portraits-standard",
      name: "Standard Session",
      price: "$650",
      description: "Our most popular portrait package for individuals and families",
      popular: true,
      features: [
        "1-hour session",
        "1-2 locations",
        "2 outfit changes",
        "30 edited digital images",
        "Online gallery",
        "Personal use rights",
        "Professional retouching",
        "5 social media-ready images"
      ],
    },
    {
      id: "portraits-extended",
      name: "Extended Session",
      price: "$950",
      description: "Comprehensive portrait session for families or professional needs",
      popular: false,
      features: [
        "2-hour session",
        "Multiple locations",
        "3 outfit changes",
        "50+ edited digital images",
        "Online gallery",
        "Personal use rights",
        "Professional retouching",
        "10 social media-ready images",
        "1 16x20 fine art print"
      ],
    }
  ],
  commercial: [
    {
      id: "commercial-basic",
      name: "Basic Commercial",
      price: "$1,500",
      description: "Product or basic commercial photography for small businesses",
      popular: false,
      features: [
        "4-hour session",
        "Up to 10 products or setups",
        "Studio or on-location",
        "50 edited digital images",
        "Commercial usage rights",
        "Basic retouching",
        "Quick turnaround (1 week)"
      ],
    },
    {
      id: "commercial-standard",
      name: "Professional Commercial",
      price: "$2,800",
      description: "Professional commercial photography for marketing campaigns",
      popular: true,
      features: [
        "Full day session (8 hours)",
        "Multiple products or setups",
        "Studio or on-location",
        "100+ edited digital images",
        "Commercial usage rights",
        "Advanced retouching",
        "Marketing-ready files",
        "Quick turnaround (1 week)",
        "Social media assets"
      ],
    },
    {
      id: "commercial-premium",
      name: "Premium Commercial",
      price: "$4,500",
      description: "Premium commercial package for comprehensive brand photography",
      popular: false,
      features: [
        "2 full-day sessions",
        "Unlimited products or setups",
        "Studio and on-location options",
        "200+ edited digital images",
        "Extended commercial usage rights",
        "Premium retouching",
        "Marketing-ready files",
        "Quick turnaround (1 week)",
        "Social media assets",
        "Art direction consultation"
      ],
    }
  ]
};

// Add-ons and additional services
const addOns = [
  {
    id: "addon-1",
    name: "Extra Hour of Coverage",
    price: "$350",
    description: "Add an extra hour of photography coverage to any package"
  },
  {
    id: "addon-2",
    name: "Second Photographer",
    price: "$500",
    description: "Add a second photographer for packages that don't already include one"
  },
  {
    id: "addon-3",
    name: "Engagement Session",
    price: "$450",
    description: "1-hour engagement photo session (included in wedding packages)"
  },
  {
    id: "addon-4",
    name: "Rush Delivery",
    price: "From $300",
    description: "Expedited delivery of your photos within 48 hours"
  },
  {
    id: "addon-5",
    name: "Wedding Album",
    price: "From $800",
    description: "Custom-designed wedding album with premium options available"
  },
  {
    id: "addon-6",
    name: "Wall Art & Prints",
    price: "From $150",
    description: "High-quality prints and wall art in various sizes"
  },
];

export default function PricingPage() {
  const [activeTab, setActiveTab] = useState("weddings");

  return (
    <>
      <PageBanner
        title="Pricing & Packages"
        subtitle="Transparent pricing for our professional photography services"
        backgroundImage="https://images.unsplash.com/photo-1502444330042-d1a1ddf9bb5b?w=1920&h=600&fit=crop"
      />

      {/* Pricing Categories */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Our Photography Packages"
            subtitle="Select the right package for your photography needs"
          />
          
          <Tabs defaultValue="weddings" className="mt-12" onValueChange={setActiveTab}>
            <div className="flex justify-center mb-8">
              <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full md:w-auto">
                <TabsTrigger value="weddings">Weddings</TabsTrigger>
                <TabsTrigger value="events">Events</TabsTrigger>
                <TabsTrigger value="portraits">Portraits</TabsTrigger>
                <TabsTrigger value="commercial">Commercial</TabsTrigger>
              </TabsList>
            </div>
            
            {/* Wedding Packages */}
            <TabsContent value="weddings" className="mt-6">
              <div className="grid md:grid-cols-3 gap-6">
                {pricingPackages.weddings.map((pkg) => (
                  <div 
                    key={pkg.id} 
                    className={`border rounded-lg overflow-hidden flex flex-col h-full ${
                      pkg.popular ? 'border-primary shadow-lg relative' : 'border-border'
                    }`}
                  >
                    {pkg.popular && (
                      <div className="absolute top-6 right-0 bg-primary text-primary-foreground py-1 px-4 text-sm font-medium">
                        Most Popular
                      </div>
                    )}
                    <div className="p-6 bg-muted/30">
                      <div className="flex items-center mb-2">
                        <Package className="h-5 w-5 text-primary mr-2" />
                        <h3 className="text-2xl font-bold">{pkg.name}</h3>
                      </div>
                      <div className="text-3xl font-bold mb-2">{pkg.price}</div>
                      <p className="text-muted-foreground text-sm">{pkg.description}</p>
                    </div>
                    <div className="p-6 flex-grow">
                      <h4 className="font-medium mb-4">What's Included:</h4>
                      <ul className="space-y-3">
                        {pkg.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-6 pt-0">
                      <Button asChild className="w-full" variant={pkg.popular ? "default" : "outline"}>
                        <Link to="/contact">Book This Package</Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            {/* Event Packages */}
            <TabsContent value="events" className="mt-6">
              <div className="grid md:grid-cols-3 gap-6">
                {pricingPackages.events.map((pkg) => (
                  <div 
                    key={pkg.id} 
                    className={`border rounded-lg overflow-hidden flex flex-col h-full ${
                      pkg.popular ? 'border-primary shadow-lg relative' : 'border-border'
                    }`}
                  >
                    {pkg.popular && (
                      <div className="absolute top-6 right-0 bg-primary text-primary-foreground py-1 px-4 text-sm font-medium">
                        Most Popular
                      </div>
                    )}
                    <div className="p-6 bg-muted/30">
                      <div className="flex items-center mb-2">
                        <Package className="h-5 w-5 text-primary mr-2" />
                        <h3 className="text-2xl font-bold">{pkg.name}</h3>
                      </div>
                      <div className="text-3xl font-bold mb-2">{pkg.price}</div>
                      <p className="text-muted-foreground text-sm">{pkg.description}</p>
                    </div>
                    <div className="p-6 flex-grow">
                      <h4 className="font-medium mb-4">What's Included:</h4>
                      <ul className="space-y-3">
                        {pkg.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-6 pt-0">
                      <Button asChild className="w-full" variant={pkg.popular ? "default" : "outline"}>
                        <Link to="/contact">Book This Package</Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            {/* Portrait Packages */}
            <TabsContent value="portraits" className="mt-6">
              <div className="grid md:grid-cols-3 gap-6">
                {pricingPackages.portraits.map((pkg) => (
                  <div 
                    key={pkg.id} 
                    className={`border rounded-lg overflow-hidden flex flex-col h-full ${
                      pkg.popular ? 'border-primary shadow-lg relative' : 'border-border'
                    }`}
                  >
                    {pkg.popular && (
                      <div className="absolute top-6 right-0 bg-primary text-primary-foreground py-1 px-4 text-sm font-medium">
                        Most Popular
                      </div>
                    )}
                    <div className="p-6 bg-muted/30">
                      <div className="flex items-center mb-2">
                        <Package className="h-5 w-5 text-primary mr-2" />
                        <h3 className="text-2xl font-bold">{pkg.name}</h3>
                      </div>
                      <div className="text-3xl font-bold mb-2">{pkg.price}</div>
                      <p className="text-muted-foreground text-sm">{pkg.description}</p>
                    </div>
                    <div className="p-6 flex-grow">
                      <h4 className="font-medium mb-4">What's Included:</h4>
                      <ul className="space-y-3">
                        {pkg.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-6 pt-0">
                      <Button asChild className="w-full" variant={pkg.popular ? "default" : "outline"}>
                        <Link to="/contact">Book This Package</Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            {/* Commercial Packages */}
            <TabsContent value="commercial" className="mt-6">
              <div className="grid md:grid-cols-3 gap-6">
                {pricingPackages.commercial.map((pkg) => (
                  <div 
                    key={pkg.id} 
                    className={`border rounded-lg overflow-hidden flex flex-col h-full ${
                      pkg.popular ? 'border-primary shadow-lg relative' : 'border-border'
                    }`}
                  >
                    {pkg.popular && (
                      <div className="absolute top-6 right-0 bg-primary text-primary-foreground py-1 px-4 text-sm font-medium">
                        Most Popular
                      </div>
                    )}
                    <div className="p-6 bg-muted/30">
                      <div className="flex items-center mb-2">
                        <Package className="h-5 w-5 text-primary mr-2" />
                        <h3 className="text-2xl font-bold">{pkg.name}</h3>
                      </div>
                      <div className="text-3xl font-bold mb-2">{pkg.price}</div>
                      <p className="text-muted-foreground text-sm">{pkg.description}</p>
                    </div>
                    <div className="p-6 flex-grow">
                      <h4 className="font-medium mb-4">What's Included:</h4>
                      <ul className="space-y-3">
                        {pkg.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-6 pt-0">
                      <Button asChild className="w-full" variant={pkg.popular ? "default" : "outline"}>
                        <Link to="/contact">Book This Package</Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
          
          <div className="text-center mt-8 text-muted-foreground">
            <p>All packages can be customized to meet your specific needs. <Link to="/contact" className="text-primary hover:underline">Contact us</Link> for custom quotes.</p>
          </div>
        </div>
      </section>

      {/* Add-ons Section */}
      <section className="py-16 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Additional Services & Add-ons"
            subtitle="Customize your package with these optional extras"
          />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
            {addOns.map((addon) => (
              <div key={addon.id} className="bg-background p-6 rounded-lg shadow-sm">
                <div className="flex justify-between items-start">
                  <h3 className="text-xl font-semibold">{addon.name}</h3>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="cursor-help">
                          <HelpCircle className="h-5 w-5 text-muted-foreground" />
                        </div>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="max-w-xs">{addon.description}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <div className="text-2xl font-bold text-primary mt-2 mb-3">{addon.price}</div>
                <p className="text-muted-foreground text-sm">{addon.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Comparison Section */}
      <section className="py-16">
        <div className="container px-4">
          <SectionHeading
            title={`Compare ${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Packages`}
            subtitle={`Feature comparison for our ${activeTab} photography packages`}
          />
          
          <div className="overflow-x-auto mt-12">
            <table className="w-full min-w-[800px] border-collapse">
              <thead>
                <tr className="border-b">
                  <th className="py-4 px-6 text-left font-medium">Feature</th>
                  {pricingPackages[activeTab as keyof typeof pricingPackages].map((pkg) => (
                    <th key={pkg.id} className="py-4 px-6 text-center font-medium">
                      {pkg.name}
                      <div className="text-muted-foreground font-normal text-sm">{pkg.price}</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {/* Dynamically generate comparison rows based on active tab */}
                {(() => {
                  // Generate all unique features across packages
                  const allFeatures = new Set<string>();
                  pricingPackages[activeTab as keyof typeof pricingPackages].forEach(pkg => {
                    pkg.features.forEach(feature => allFeatures.add(feature));
                  });
                  
                  return Array.from(allFeatures).map((feature, index) => (
                    <tr key={index} className={index % 2 === 0 ? 'bg-muted/30' : ''}>
                      <td className="py-3 px-6 border-b">{feature}</td>
                      {pricingPackages[activeTab as keyof typeof pricingPackages].map((pkg) => (
                        <td key={`${pkg.id}-${index}`} className="py-3 px-6 text-center border-b">
                          {pkg.features.includes(feature) ? (
                            <CheckCircle className="h-5 w-5 text-primary mx-auto" />
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                      ))}
                    </tr>
                  ));
                })()}
                {/* Book Now Row */}
                <tr>
                  <td className="py-4 px-6"></td>
                  {pricingPackages[activeTab as keyof typeof pricingPackages].map((pkg) => (
                    <td key={`${pkg.id}-book`} className="py-4 px-6 text-center">
                      <Button asChild variant={pkg.popular ? "default" : "outline"} size="sm">
                        <Link to="/contact">Book Now</Link>
                      </Button>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Frequently Asked Questions"
            subtitle="Common questions about our pricing and packages"
          />
          
          <div className="grid md:grid-cols-2 gap-x-12 gap-y-8 mt-12">
            {[
              {
                question: "Do you offer custom packages?",
                answer: "Yes, we understand that every client's needs are unique. We're happy to create custom packages tailored to your specific requirements. Please contact us to discuss your needs and receive a custom quote."
              },
              {
                question: "What is your payment policy?",
                answer: "We require a 50% deposit to secure your booking, with the remaining balance due one week before the event or session. For weddings, a non-refundable retainer of $1,000 is required to reserve your date."
              },
              {
                question: "Do you offer payment plans?",
                answer: "Yes, we offer flexible payment plans for our wedding packages. After the initial deposit, the remaining balance can be divided into monthly payments leading up to your event date."
              },
              {
                question: "What forms of payment do you accept?",
                answer: "We accept credit cards, bank transfers, and cash. All online payments are processed securely through our booking system."
              },
              {
                question: "Are travel fees included in your packages?",
                answer: "Our packages include travel within 50 miles of our studio. Beyond that, travel fees may apply at $0.75 per mile. For destination weddings or events, please contact us for a custom quote."
              },
              {
                question: "What is your cancellation policy?",
                answer: "Cancellations made more than 60 days before your wedding receive a refund of payments minus the non-refundable retainer. For other sessions, cancellations with at least 14 days' notice receive a full refund."
              }
            ].map((faq, index) => (
              <div key={index} className="mb-6">
                <h4 className="text-lg font-semibold mb-2">{faq.question}</h4>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Book Your Photography Session?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Contact us today to check our availability and reserve your preferred date.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg">
              <Link to="/contact">Book Now</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/portfolio">View Portfolio</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}