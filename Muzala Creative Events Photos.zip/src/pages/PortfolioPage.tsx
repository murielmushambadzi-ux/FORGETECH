import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PageBanner from "@/components/PageBanner";
import ImageGallery from "@/components/ImageGallery";
import SectionHeading from "@/components/SectionHeading";

// Portfolio categories and images
const categories = [
  { id: "all", name: "All Work" },
  { id: "weddings", name: "Weddings" },
  { id: "events", name: "Events" },
  { id: "portraits", name: "Portraits" },
  { id: "commercial", name: "Commercial" },
];

const portfolioImages = {
  weddings: [
    {
      id: 1,
      url: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=800&h=600&fit=crop",
      alt: "Bride and groom laughing"
    },
    {
      id: 2,
      url: "https://images.unsplash.com/photo-1519741347686-c1e0aadf4611?w=800&h=600&fit=crop",
      alt: "Couple's first dance"
    },
    {
      id: 3,
      url: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&h=600&fit=crop",
      alt: "Wedding rings close-up"
    },
    {
      id: 4,
      url: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?w=800&h=600&fit=crop",
      alt: "Wedding venue decoration"
    },
    {
      id: 5,
      url: "https://images.unsplash.com/photo-1507504031003-ba985c5c963f?w=800&h=600&fit=crop",
      alt: "Bridal preparation"
    },
    {
      id: 6,
      url: "https://images.unsplash.com/photo-1606800052052-a08af7148866?w=800&h=600&fit=crop",
      alt: "Wedding ceremony"
    },
    {
      id: 7,
      url: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?w=800&h=600&fit=crop",
      alt: "Bride portrait"
    },
    {
      id: 8,
      url: "https://images.unsplash.com/photo-1606216794074-735e91daa580?w=800&h=600&fit=crop",
      alt: "Wedding couple outdoor portrait"
    },
  ],
  events: [
    {
      id: 9,
      url: "https://images.unsplash.com/photo-1540317580384-e5d43867caa6?w=800&h=600&fit=crop",
      alt: "Corporate conference"
    },
    {
      id: 10,
      url: "https://images.unsplash.com/photo-1511578314322-379afb476865?w=800&h=600&fit=crop",
      alt: "Award ceremony"
    },
    {
      id: 11,
      url: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=800&h=600&fit=crop",
      alt: "Company party"
    },
    {
      id: 12,
      url: "https://images.unsplash.com/photo-1528605248644-14dd04022da1?w=800&h=600&fit=crop",
      alt: "Team building event"
    },
    {
      id: 13,
      url: "https://images.unsplash.com/photo-1530023367847-a683933f4172?w=800&h=600&fit=crop",
      alt: "Birthday celebration"
    },
    {
      id: 14,
      url: "https://images.unsplash.com/photo-1516997121675-4c2d1684aa3e?w=800&h=600&fit=crop",
      alt: "Product launch event"
    },
  ],
  portraits: [
    {
      id: 15,
      url: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=800&h=600&fit=crop",
      alt: "Female portrait with natural light"
    },
    {
      id: 16,
      url: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=800&h=600&fit=crop",
      alt: "Male portrait with glasses"
    },
    {
      id: 17,
      url: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=800&h=600&fit=crop",
      alt: "Professional headshot of young woman"
    },
    {
      id: 18,
      url: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=800&h=600&fit=crop",
      alt: "Smiling man portrait"
    },
    {
      id: 19,
      url: "https://images.unsplash.com/photo-1527203561188-dae1bc1a417f?w=800&h=600&fit=crop",
      alt: "Family portrait outdoors"
    },
    {
      id: 20,
      url: "https://images.unsplash.com/photo-1610631787813-9eeb1a2386cc?w=800&h=600&fit=crop",
      alt: "Senior portrait session"
    },
  ],
  commercial: [
    {
      id: 21,
      url: "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=800&h=600&fit=crop",
      alt: "Watch product photography"
    },
    {
      id: 22,
      url: "https://images.unsplash.com/photo-1611930022073-84f3bb4caa4b?w=800&h=600&fit=crop",
      alt: "Food photography setup"
    },
    {
      id: 23,
      url: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800&h=600&fit=crop",
      alt: "Makeup product flat lay"
    },
    {
      id: 24,
      url: "https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=800&h=600&fit=crop",
      alt: "Office interior for real estate"
    },
    {
      id: 25,
      url: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&h=600&fit=crop",
      alt: "Fashion photography"
    },
    {
      id: 26,
      url: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&h=600&fit=crop",
      alt: "Headphone product photography"
    },
  ],
};

// Featured projects with more details
const featuredProjects = [
  {
    id: 1,
    title: "Smith-Johnson Wedding",
    category: "Weddings",
    description: "An elegant garden wedding featuring vintage details and natural light photography.",
    image: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=1200&h=800&fit=crop",
    date: "June 2025"
  },
  {
    id: 2,
    title: "TechCorp Annual Gala",
    category: "Events",
    description: "Corporate award ceremony and fundraising event for a leading technology company.",
    image: "https://images.unsplash.com/photo-1511578314322-379afb476865?w=1200&h=800&fit=crop",
    date: "March 2025"
  },
  {
    id: 3,
    title: "Elite Fashion Campaign",
    category: "Commercial",
    description: "Summer collection promotional photoshoot for a premium fashion brand.",
    image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=1200&h=800&fit=crop",
    date: "May 2025"
  }
];

export default function PortfolioPage() {
  const [activeTab, setActiveTab] = useState("all");

  // Combine all images for the "all" category
  const allImages = [
    ...portfolioImages.weddings,
    ...portfolioImages.events, 
    ...portfolioImages.portraits,
    ...portfolioImages.commercial
  ];

  // Get images based on active tab
  const getDisplayImages = () => {
    if (activeTab === "all") return allImages;
    return portfolioImages[activeTab as keyof typeof portfolioImages] || [];
  };

  return (
    <>
      <PageBanner
        title="Our Portfolio"
        subtitle="Explore our diverse collection of professional photography work"
        backgroundImage="https://images.unsplash.com/photo-1452587925148-ce544e77e70d?w=1920&h=600&fit=crop"
      />

      {/* Featured Projects */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Featured Projects"
            subtitle="Highlighting some of our favorite recent work"
          />
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            {featuredProjects.map((project) => (
              <div key={project.id} className="group">
                <div className="relative overflow-hidden rounded-lg mb-4">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full aspect-[4/3] object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end">
                    <div className="p-4 text-white">
                      <span className="text-sm font-medium">{project.date}</span>
                    </div>
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-1">{project.title}</h3>
                <div className="text-sm text-primary mb-2">{project.category}</div>
                <p className="text-muted-foreground">{project.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Gallery */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Photography Portfolio"
            subtitle="Browse through our diverse collection of professional photography"
          />

          <Tabs defaultValue="all" className="mt-12" onValueChange={setActiveTab}>
            <div className="flex justify-center mb-8">
              <TabsList className="grid grid-cols-2 md:grid-cols-5">
                {categories.map((category) => (
                  <TabsTrigger key={category.id} value={category.id}>
                    {category.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>

            {categories.map((category) => (
              <TabsContent key={category.id} value={category.id} className="mt-6">
                <ImageGallery 
                  images={getDisplayImages()} 
                  columns={category.id === "all" ? 4 : 3}
                />
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      {/* Client List */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Clients We've Worked With"
            subtitle="Trusted by individuals, couples, and businesses alike"
          />
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 mt-12">
            {[
              "TechCorp International",
              "Luxe Hotels & Resorts",
              "StyleNow Magazine",
              "Fresh Eats Restaurant",
              "Urban Fitness Club",
              "City Art Gallery",
              "Summit Financial Group",
              "Green Earth Foundation",
              "Modern Living Magazine",
              "First National Bank",
              "Bright Future Academy",
              "Coastal Breeze Resort"
            ].map((client, index) => (
              <div 
                key={index} 
                className="flex items-center justify-center h-24 px-4 bg-muted/50 rounded-lg text-center"
              >
                <span className="font-medium text-sm">{client}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-secondary text-secondary-foreground">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Create Your Own Project?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Let's work together to capture your special moments or create stunning visuals for your brand.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg" className="bg-primary hover:bg-primary/90">
              <Link to="/contact">Start a Project</Link>
            </Button>
            <Button asChild variant="outline" className="bg-transparent text-secondary-foreground border-secondary-foreground hover:bg-secondary-foreground/20" size="lg">
              <Link to="/pricing">View Pricing</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}