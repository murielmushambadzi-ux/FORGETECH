import { Camera, Clock, Heart, MapPin, Mail, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import PageBanner from '@/components/PageBanner';
import SectionHeading from '@/components/SectionHeading';

const team = [
  {
    id: 1,
    name: "Alex Muzala",
    role: "Founder & Lead Photographer",
    bio: "Professional photographer with over 10 years of experience specializing in wedding and portrait photography.",
    image: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=400&h=400&fit=crop",
  },
  {
    id: 2,
    name: "Sarah Johnson",
    role: "Event Photographer",
    bio: "Award-winning event photographer with a talent for capturing candid and spontaneous moments.",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop",
  },
  {
    id: 3,
    name: "David Chen",
    role: "Commercial Photographer",
    bio: "Specialized in commercial and product photography with a keen eye for composition and lighting.",
    image: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&h=400&fit=crop",
  },
  {
    id: 4,
    name: "Emily Rodriguez",
    role: "Portrait Specialist",
    bio: "Portrait specialist who excels at bringing out the unique personality and beauty in every client.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop",
  }
];

const values = [
  {
    id: 1,
    icon: <Camera className="h-8 w-8 text-primary" />,
    title: "Quality Excellence",
    description: "We are committed to delivering the highest quality photographs that exceed your expectations.",
  },
  {
    id: 2,
    icon: <Clock className="h-8 w-8 text-primary" />,
    title: "Punctuality",
    description: "We respect your time and schedule, ensuring we're always prepared and punctual.",
  },
  {
    id: 3,
    icon: <Heart className="h-8 w-8 text-primary" />,
    title: "Passion & Creativity",
    description: "We approach each project with passion, creativity, and a fresh perspective.",
  }
];

export default function AboutPage() {
  return (
    <>
      <PageBanner
        title="About MUZALA CREATIVE"
        subtitle="Learn about our story, mission, and the team behind the lens"
        backgroundImage="https://images.unsplash.com/photo-1560932684-5e552e2894e9?w=1920&h=600&fit=crop"
      />

      {/* Our Story */}
      <section className="py-20">
        <div className="container px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <p className="text-muted-foreground mb-4">
                Founded in 2013 by Alex Muzala, MUZALA CREATIVE began as a small photography studio with a big vision: 
                to capture life's beautiful moments with artistic excellence and technical precision.
              </p>
              <p className="text-muted-foreground mb-4">
                What started as a passion project quickly grew into one of the most sought-after photography studios in the region. 
                Over the years, we've had the honor of documenting thousands of special moments, from intimate weddings to 
                large-scale corporate events.
              </p>
              <p className="text-muted-foreground">
                Today, our team of talented photographers continues to push creative boundaries while maintaining our core 
                values of quality, reliability, and artistic integrity. We're proud of our journey and excited about the 
                countless moments we have yet to capture.
              </p>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=800&h=800&fit=crop" 
                alt="Photography studio" 
                className="rounded-lg shadow-lg"
              />
              <div className="absolute -bottom-5 -left-5 w-32 h-32 bg-primary rounded-lg flex items-center justify-center text-center p-2">
                <div>
                  <div className="text-3xl font-bold text-primary-foreground">10+</div>
                  <div className="text-sm text-primary-foreground/80">Years of Experience</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Our Core Values"
            subtitle="The principles that guide our work and define our approach"
          />
          <div className="grid md:grid-cols-3 gap-8">
            {values.map((value) => (
              <div key={value.id} className="bg-background rounded-lg p-8 shadow-sm">
                <div className="mb-4">{value.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                <p className="text-muted-foreground">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Mission */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Mission</h2>
            <p className="text-lg mb-0">
              "At MUZALA CREATIVE, our mission is to transform ordinary moments into extraordinary memories through the art of photography. 
              We believe in creating images that not only document events but evoke emotions, tell stories, and stand the test of time. 
              We are committed to providing an exceptional client experience from the first consultation to the final delivery of your photographs."
            </p>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Meet Our Team"
            subtitle="The talented photographers behind MUZALA CREATIVE"
          />
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((member) => (
              <div key={member.id} className="text-center">
                <div className="mb-4 overflow-hidden rounded-lg">
                  <img 
                    src={member.image} 
                    alt={member.name} 
                    className="w-full h-auto transition-transform duration-300 hover:scale-105"
                  />
                </div>
                <h3 className="text-xl font-semibold">{member.name}</h3>
                <p className="text-primary text-sm mb-2">{member.role}</p>
                <p className="text-muted-foreground text-sm">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Studio Location */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Visit Our Studio</h2>
              <p className="text-muted-foreground mb-6">
                Our modern photography studio is equipped with state-of-the-art equipment and versatile shooting spaces.
                Feel free to visit us during our business hours or schedule an appointment to discuss your photography needs.
              </p>
              <div className="space-y-4">
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 text-primary mr-2" />
                  <span>123 Photography Lane, Creative City, ST 12345</span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-5 w-5 text-primary mr-2" />
                  <span>+1 (234) 567-8900</span>
                </div>
                <div className="flex items-center">
                  <Mail className="h-5 w-5 text-primary mr-2" />
                  <span>info@muzalacreative.com</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-primary mr-2" />
                  <span>Monday - Friday: 9:00 AM - 6:00 PM</span>
                </div>
              </div>
              <div className="mt-8">
                <Button asChild>
                  <Link to="/contact">Contact Us</Link>
                </Button>
              </div>
            </div>
            <div>
              <div className="aspect-video w-full rounded-lg overflow-hidden shadow-lg">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.30597735!2d-74.25986543435541!3d40.69714941680757!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2s!4v1595446965862!5m2!1sen!2s" 
                  width="100%" 
                  height="100%" 
                  style={{ border: 0 }} 
                  allowFullScreen={true} 
                  loading="lazy"
                  title="Studio Location"
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-secondary text-secondary-foreground">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Let's Work Together</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Ready to create something beautiful? Contact us today to discuss your photography needs.
          </p>
          <Button asChild size="lg" className="bg-primary hover:bg-primary/90">
            <Link to="/contact">Get in Touch</Link>
          </Button>
        </div>
      </section>
    </>
  );
}