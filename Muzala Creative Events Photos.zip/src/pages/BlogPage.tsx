import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Calendar, User, Clock, Search, ChevronLeft, ChevronRight, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import PageBanner from "@/components/PageBanner";
import SectionHeading from "@/components/SectionHeading";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

// Sample blog posts data
const blogPosts = [
  {
    id: 1,
    title: "10 Tips for Perfect Wedding Photos",
    excerpt: "Expert advice on how to ensure your wedding photography captures all the special moments of your big day.",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique...",
    image: "https://images.unsplash.com/photo-1519741347686-c1e0aadf4611?w=800&h=500&fit=crop",
    author: "Alex Muzala",
    authorImage: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=100&h=100&fit=crop",
    date: "July 15, 2025",
    readTime: "8 min read",
    category: "Wedding",
    tags: ["wedding", "tips", "photography"]
  },
  {
    id: 2,
    title: "How to Prepare for Your Portrait Session",
    excerpt: "From clothing choices to location scouting, these preparations will help you get the most out of your portrait photoshoot.",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique...",
    image: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=800&h=500&fit=crop",
    author: "Sarah Johnson",
    authorImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop",
    date: "July 10, 2025",
    readTime: "6 min read",
    category: "Portraits",
    tags: ["portraits", "preparation", "tips"]
  },
  {
    id: 3,
    title: "The Art of Corporate Event Photography",
    excerpt: "Insights into capturing professional and engaging images at corporate events and conferences.",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique...",
    image: "https://images.unsplash.com/photo-1540317580384-e5d43867caa6?w=800&h=500&fit=crop",
    author: "David Chen",
    authorImage: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&h=100&fit=crop",
    date: "July 5, 2025",
    readTime: "7 min read",
    category: "Events",
    tags: ["corporate", "events", "business"]
  },
  {
    id: 4,
    title: "Lighting Techniques for Better Photos",
    excerpt: "Learn the fundamentals of lighting that can transform your photographs from amateur to professional.",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique...",
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&h=500&fit=crop",
    author: "Emily Rodriguez",
    authorImage: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    date: "June 28, 2025",
    readTime: "10 min read",
    category: "Technical",
    tags: ["lighting", "techniques", "education"]
  },
  {
    id: 5,
    title: "Choosing the Right Colors for Your Product Photography",
    excerpt: "How color theory and psychology can enhance your product photos and boost sales.",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique...",
    image: "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=800&h=500&fit=crop",
    author: "Alex Muzala",
    authorImage: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=100&h=100&fit=crop",
    date: "June 20, 2025",
    readTime: "9 min read",
    category: "Commercial",
    tags: ["product", "color", "commercial"]
  },
  {
    id: 6,
    title: "Camera Gear: What's in Our Bag",
    excerpt: "Explore the professional camera equipment we use for different types of photography sessions.",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique...",
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&h=500&fit=crop",
    author: "David Chen",
    authorImage: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&h=100&fit=crop",
    date: "June 15, 2025",
    readTime: "8 min read",
    category: "Equipment",
    tags: ["equipment", "camera", "gear"]
  },
  {
    id: 7,
    title: "Creative Family Portrait Ideas",
    excerpt: "Moving beyond traditional poses to capture authentic family moments and connections.",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique...",
    image: "https://images.unsplash.com/photo-1527203561188-dae1bc1a417f?w=800&h=500&fit=crop",
    author: "Sarah Johnson",
    authorImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop",
    date: "June 8, 2025",
    readTime: "7 min read",
    category: "Portraits",
    tags: ["family", "portraits", "creative"]
  },
  {
    id: 8,
    title: "Behind the Scenes: Fashion Photoshoot",
    excerpt: "A look at what goes into creating stunning fashion and lifestyle photography.",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique...",
    image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&h=500&fit=crop",
    author: "Emily Rodriguez",
    authorImage: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    date: "June 1, 2025",
    readTime: "6 min read",
    category: "Commercial",
    tags: ["fashion", "behind-the-scenes", "commercial"]
  }
];

// Get unique categories
const categories = ["All", ...new Set(blogPosts.map(post => post.category))];

// Get unique tags
const tags = [...new Set(blogPosts.flatMap(post => post.tags))].sort();

export default function BlogPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [currentPage, setCurrentPage] = useState(1);
  const [filteredPosts, setFilteredPosts] = useState(blogPosts);
  const postsPerPage = 4;

  // Filter posts based on search term and category
  useEffect(() => {
    let filtered = blogPosts;
    
    // Filter by search term
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      filtered = filtered.filter(post => 
        post.title.toLowerCase().includes(searchLower) || 
        post.excerpt.toLowerCase().includes(searchLower) || 
        post.tags.some(tag => tag.toLowerCase().includes(searchLower))
      );
    }
    
    // Filter by category
    if (selectedCategory !== "All") {
      filtered = filtered.filter(post => post.category === selectedCategory);
    }
    
    setFilteredPosts(filtered);
    setCurrentPage(1); // Reset to first page when filters change
  }, [searchTerm, selectedCategory]);

  // Get current posts
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = filteredPosts.slice(indexOfFirstPost, indexOfLastPost);
  const totalPages = Math.ceil(filteredPosts.length / postsPerPage);

  return (
    <>
      <PageBanner
        title="Photography Blog"
        subtitle="Insights, tips, and stories from our photography adventures"
        backgroundImage="https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=1920&h=600&fit=crop"
      />

      {/* Blog Controls */}
      <section className="py-10">
        <div className="container px-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="relative w-full md:w-72">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                type="text"
                placeholder="Search articles..."
                className="pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex items-center space-x-2 overflow-x-auto whitespace-nowrap pb-1 w-full md:w-auto">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Post */}
      <section className="py-8">
        <div className="container px-4">
          {filteredPosts.length > 0 && currentPage === 1 && (
            <div className="grid md:grid-cols-2 gap-8 items-center bg-muted/30 p-6 md:p-8 rounded-lg">
              <div className="overflow-hidden rounded-lg">
                <img 
                  src={filteredPosts[0].image} 
                  alt={filteredPosts[0].title}
                  className="w-full h-auto aspect-[4/3] object-cover transition-transform duration-500 hover:scale-105"
                />
              </div>
              <div>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-2">
                  <span className="bg-primary/10 text-primary px-2 py-1 rounded-md">
                    {filteredPosts[0].category}
                  </span>
                  <span className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    {filteredPosts[0].date}
                  </span>
                  <span className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {filteredPosts[0].readTime}
                  </span>
                </div>
                <h2 className="text-2xl md:text-3xl font-bold mb-3">
                  {filteredPosts[0].title}
                </h2>
                <p className="text-muted-foreground mb-4">
                  {filteredPosts[0].excerpt}
                </p>
                <div className="flex items-center mb-6">
                  <img 
                    src={filteredPosts[0].authorImage} 
                    alt={filteredPosts[0].author}
                    className="w-8 h-8 rounded-full mr-2 object-cover"
                  />
                  <span className="text-sm">By {filteredPosts[0].author}</span>
                </div>
                <Button>Read Article</Button>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Blog Posts Grid */}
      <section className="py-12">
        <div className="container px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {currentPosts.slice(currentPage === 1 ? 1 : 0).map((post) => (
              <Card key={post.id} className="overflow-hidden h-full flex flex-col">
                <div className="aspect-[16/9] overflow-hidden">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                </div>
                <CardContent className="p-6 flex-grow flex flex-col">
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-2">
                    <span className="bg-primary/10 text-primary px-2 py-1 rounded-md">
                      {post.category}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{post.title}</h3>
                  <p className="text-muted-foreground mb-4 flex-grow">{post.excerpt}</p>
                  <div className="flex flex-wrap gap-1 mb-4">
                    {post.tags.map((tag) => (
                      <span 
                        key={tag}
                        className="inline-flex items-center text-xs bg-muted px-2 py-1 rounded"
                      >
                        <Tag className="h-3 w-3 mr-1" />
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <img 
                        src={post.authorImage} 
                        alt={post.author}
                        className="w-8 h-8 rounded-full mr-2 object-cover"
                      />
                      <div className="text-sm">
                        <span className="block">{post.author}</span>
                        <span className="block text-muted-foreground text-xs">{post.date}</span>
                      </div>
                    </div>
                    <span className="flex items-center text-sm text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      {post.readTime}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center space-x-2 mt-12">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              {Array.from({ length: totalPages }).map((_, index) => (
                <Button
                  key={index}
                  variant={currentPage === index + 1 ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentPage(index + 1)}
                >
                  {index + 1}
                </Button>
              ))}
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
          
          {filteredPosts.length === 0 && (
            <div className="text-center py-20">
              <h3 className="text-2xl font-semibold mb-2">No Articles Found</h3>
              <p className="text-muted-foreground mb-6">
                No articles match your current search criteria. Try adjusting your filters.
              </p>
              <Button 
                onClick={() => {
                  setSelectedCategory("All");
                  setSearchTerm("");
                }}
              >
                Reset Filters
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Sidebar/Categories Section */}
      <section className="py-16 bg-muted/30">
        <div className="container px-4">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Popular Tags */}
            <div>
              <h3 className="text-xl font-semibold mb-4">Popular Tags</h3>
              <div className="flex flex-wrap gap-2">
                {tags.map((tag) => (
                  <Button 
                    key={tag} 
                    variant="outline" 
                    size="sm"
                    onClick={() => setSearchTerm(tag)}
                    className="text-sm"
                  >
                    #{tag}
                  </Button>
                ))}
              </div>
            </div>

            {/* Categories */}
            <div>
              <h3 className="text-xl font-semibold mb-4">Categories</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <Button 
                    key={category} 
                    variant="ghost" 
                    className={`w-full justify-start ${selectedCategory === category ? 'text-primary' : ''}`}
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>

            {/* Newsletter Signup */}
            <div className="p-6 bg-background rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Subscribe to Our Newsletter</h3>
              <p className="text-muted-foreground mb-4">
                Get the latest photography tips, tricks, and inspiration delivered to your inbox.
              </p>
              <div className="space-y-3">
                <Input placeholder="Your email address" />
                <Button className="w-full">Subscribe</Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container px-4 text-center">
          <SectionHeading
            title="Want to Work Together?"
            subtitle="Let's create beautiful photographs for your next project"
          />
          <div className="flex flex-wrap justify-center gap-4 mt-8">
            <Button asChild size="lg">
              <Link to="/contact">Contact Us</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/services">Explore Services</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}