import { Link } from 'react-router-dom';
import { CheckCircle, Package, User, Clock, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PageBanner from '@/components/PageBanner';
import SectionHeading from '@/components/SectionHeading';
import ImageGallery from '@/components/ImageGallery';

const portraitPackages = [
  {
    id: 1,
    name: "Mini Session",
    price: "$350",
    description: "Quick session for individual portraits or headshots",
    features: [
      "30-minute session",
      "1 location",
      "1 outfit change",
      "15 edited digital images",
      "Online gallery",
      "Personal use rights",
      "Quick turnaround (1 week)"
    ],
  },
  {
    id: 2,
    name: "Standard Session",
    price: "$650",
    description: "Our most popular portrait package for individuals and families",
    popular: true,
    features: [
      "1-hour session",
      "1-2 locations",
      "2 outfit changes",
      "30 edited digital images",
      "Online gallery",
      "Personal use rights",
      "Professional retouching",
      "5 social media-ready images"
    ],
  },
  {
    id: 3,
    name: "Extended Session",
    price: "$950",
    description: "Comprehensive portrait session for families or professional needs",
    features: [
      "2-hour session",
      "Multiple locations",
      "3 outfit changes",
      "50+ edited digital images",
      "Online gallery",
      "Personal use rights",
      "Professional retouching",
      "10 social media-ready images",
      "1 16x20 fine art print"
    ],
  },
];

const portfolioImages = [
  {
    id: 1,
    url: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=800&h=600&fit=crop",
    alt: "Female portrait with natural light"
  },
  {
    id: 2,
    url: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=800&h=600&fit=crop",
    alt: "Male portrait with glasses"
  },
  {
    id: 3,
    url: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=800&h=600&fit=crop",
    alt: "Professional headshot of young woman"
  },
  {
    id: 4,
    url: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=800&h=600&fit=crop",
    alt: "Smiling man portrait"
  },
  {
    id: 5,
    url: "https://images.unsplash.com/photo-1527203561188-dae1bc1a417f?w=800&h=600&fit=crop",
    alt: "Family portrait outdoors"
  },
  {
    id: 6,
    url: "https://images.unsplash.com/photo-1610631787813-9eeb1a2386cc?w=800&h=600&fit=crop",
    alt: "Senior portrait session"
  },
];

const portraitTypes = [
  {
    title: "Individual Portraits",
    description: "Professional portraits that capture your personality and style.",
    image: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=600&h=400&fit=crop"
  },
  {
    title: "Family Portraits",
    description: "Beautiful family photographs that preserve your special connections.",
    image: "https://images.unsplash.com/photo-1527203561188-dae1bc1a417f?w=600&h=400&fit=crop"
  },
  {
    title: "Professional Headshots",
    description: "Polished headshots for business professionals and creatives.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=600&h=400&fit=crop"
  },
  {
    title: "Senior Portraits",
    description: "Celebrate this important milestone with unique senior photos.",
    image: "https://images.unsplash.com/photo-1610631787813-9eeb1a2386cc?w=600&h=400&fit=crop"
  }
];

export default function PortraitServicesPage() {
  return (
    <>
      <PageBanner
        title="Portrait Photography"
        subtitle="Professional portrait photography that captures personality and creates timeless images"
        backgroundImage="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=1920&h=600&fit=crop"
      />

      {/* Service Overview */}
      <section className="py-20">
        <div className="container px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Portraits That Tell Your Story</h2>
              <p className="text-muted-foreground mb-4">
                At MUZALA CREATIVE, we believe that a portrait should capture more than just appearance—it should reveal character, personality, and emotion. Our portrait photography sessions are designed to create authentic, beautiful images that truly represent you or your family.
              </p>
              <p className="text-muted-foreground mb-4">
                Whether you need professional headshots for your career, family portraits to decorate your home, senior photos to commemorate a milestone, or personal portraits to express your individuality, our experienced photographers will work with you to create images you'll love.
              </p>
              <p className="text-muted-foreground mb-6">
                We take the time to understand your vision, make you comfortable in front of the camera, and direct you with expert guidance to ensure natural, flattering portraits that stand the test of time.
              </p>
              <div className="flex flex-wrap gap-4 mt-8">
                <Button asChild>
                  <Link to="/contact">Book Your Session</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/portfolio">View Portfolio</Link>
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <img 
                  src="https://images.unsplash.com/photo-1580489944761-15a19d654956?w=500&h=750&fit=crop"
                  alt="Professional woman portrait"
                  className="w-full h-auto rounded-lg shadow-lg"
                />
                <img 
                  src="https://images.unsplash.com/photo-1527203561188-dae1bc1a417f?w=500&h=333&fit=crop"
                  alt="Family portrait"
                  className="w-full h-auto rounded-lg shadow-lg"
                />
              </div>
              <div className="pt-8">
                <img 
                  src="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=500&h=750&fit=crop"
                  alt="Woman portrait"
                  className="w-full h-auto rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Portrait Types */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Portrait Photography Types"
            subtitle="Specialized portrait services for every need"
          />
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
            {portraitTypes.map((type, index) => (
              <div key={index} className="bg-background rounded-lg overflow-hidden shadow-sm">
                <div className="aspect-[4/3] overflow-hidden">
                  <img 
                    src={type.image} 
                    alt={type.title}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                  />
                </div>
                <div className="p-5">
                  <h3 className="text-xl font-semibold mb-2">{type.title}</h3>
                  <p className="text-muted-foreground">{type.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Approach */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Our Portrait Photography Approach"
            subtitle="How we create stunning portraits that capture your essence"
          />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            {[
              {
                icon: <User className="h-10 w-10 text-primary" />,
                title: "Personal Connection",
                description: "We take time to understand you, your preferences, and what makes you unique before picking up the camera."
              },
              {
                icon: <MapPin className="h-10 w-10 text-primary" />,
                title: "Perfect Locations",
                description: "Whether in our studio or at a meaningful outdoor location, we help choose settings that enhance your portraits."
              },
              {
                icon: <Clock className="h-10 w-10 text-primary" />,
                title: "Relaxed Sessions",
                description: "We never rush our sessions, ensuring you have time to get comfortable and enjoy the experience."
              }
            ].map((item, index) => (
              <div key={index} className="bg-muted/30 p-6 rounded-lg">
                <div className="mb-4">{item.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Portrait Photography Packages"
            subtitle="Choose the perfect portrait session for your needs"
          />
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            {portraitPackages.map((pkg) => (
              <div 
                key={pkg.id} 
                className={`border rounded-lg overflow-hidden flex flex-col h-full bg-background ${
                  pkg.popular ? 'border-primary shadow-lg relative' : 'border-border'
                }`}
              >
                {pkg.popular && (
                  <div className="absolute top-6 right-0 bg-primary text-primary-foreground py-1 px-4 text-sm font-medium">
                    Most Popular
                  </div>
                )}
                <div className="p-6 bg-muted/30">
                  <div className="flex items-center mb-2">
                    <Package className="h-5 w-5 text-primary mr-2" />
                    <h3 className="text-2xl font-bold">{pkg.name}</h3>
                  </div>
                  <div className="text-3xl font-bold mb-2">{pkg.price}</div>
                  <p className="text-muted-foreground text-sm">{pkg.description}</p>
                </div>
                <div className="p-6 flex-grow">
                  <h4 className="font-medium mb-4">What's Included:</h4>
                  <ul className="space-y-3">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-6 pt-0">
                  <Button asChild className="w-full" variant={pkg.popular ? "default" : "outline"}>
                    <Link to="/contact">Book This Package</Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-8 text-muted-foreground">
            <p>Looking for something different? <Link to="/contact" className="text-primary underline">Contact us</Link> about custom portrait packages.</p>
          </div>
        </div>
      </section>

      {/* Portfolio Preview */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Portrait Photography Portfolio"
            subtitle="Examples of our portrait photography work"
          />
          <ImageGallery images={portfolioImages} />
          <div className="text-center mt-12">
            <Button asChild>
              <Link to="/portfolio">View Full Portrait Portfolio</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* What to Expect */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto">
            <SectionHeading
              title="What to Expect"
              subtitle="Our portrait session process from start to finish"
            />
            
            <div className="space-y-12 mt-12">
              {[
                {
                  step: "1",
                  title: "Consultation",
                  description: "We'll discuss your vision, preferred style, location options, and what to wear to ensure your portraits align with your goals."
                },
                {
                  step: "2",
                  title: "Photo Session",
                  description: "During your session, we'll guide you with posing direction while creating a relaxed atmosphere to capture authentic expressions."
                },
                {
                  step: "3", 
                  title: "Image Selection",
                  description: "After your session, you'll receive access to a private online gallery where you can select your favorite images."
                },
                {
                  step: "4",
                  title: "Professional Editing",
                  description: "Your selected images will undergo professional editing to enhance their quality while maintaining a natural appearance."
                },
                {
                  step: "5",
                  title: "Final Delivery",
                  description: "Receive your beautifully edited portraits via digital download, with options for professional printing available."
                }
              ].map((step, index) => (
                <div key={index} className="flex gap-6">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
                      {step.step}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Preparation Tips */}
      <section className="py-20">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto">
            <SectionHeading
              title="Portrait Session Preparation Tips"
              subtitle="How to prepare for your portrait photography session"
            />
            
            <div className="mt-12 space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-2">Clothing & Accessories</h3>
                <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                  <li>Choose clothing that makes you feel confident and comfortable</li>
                  <li>Coordinate colors without matching exactly (for group/family sessions)</li>
                  <li>Avoid large logos, graphics, or extremely bright neon colors</li>
                  <li>Consider bringing accessories that reflect your personality</li>
                  <li>Bring multiple outfit options for variety</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Grooming & Appearance</h3>
                <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                  <li>Schedule haircuts 1-2 weeks before your session</li>
                  <li>Keep makeup natural and slightly heavier than everyday wear</li>
                  <li>Ensure nails are well-groomed (they'll show in some poses)</li>
                  <li>Get plenty of rest the night before your session</li>
                  <li>Stay hydrated for healthy-looking skin</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Session Day Tips</h3>
                <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                  <li>Arrive well-rested and with time to spare</li>
                  <li>Bring water and small snacks (especially for family sessions)</li>
                  <li>For families with young children, schedule during their best time of day</li>
                  <li>Have meaningful props or items to incorporate if desired</li>
                  <li>Most importantly, come ready to have fun and enjoy the experience!</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial */}
      <section className="py-20 bg-secondary text-secondary-foreground">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">What Our Portrait Clients Say</h2>
            <div className="text-3xl italic mb-6">
              "I've never felt so comfortable during a photoshoot. The team at MUZALA CREATIVE knew exactly how to bring out my best features and personality. The photos are beautiful and really captured my essence. Highly recommend!"
            </div>
            <div className="font-medium">Emma Rodriguez</div>
            <div className="text-sm">Portrait Client</div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Book Your Portrait Session?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Contact us today to schedule your portrait photography session.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg">
              <Link to="/contact">Book Your Session</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/pricing">View All Pricing</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}