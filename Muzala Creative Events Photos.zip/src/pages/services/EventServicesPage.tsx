import { Link } from 'react-router-dom';
import { CheckCircle, Package, Clock, Zap, Users, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PageBanner from '@/components/PageBanner';
import SectionHeading from '@/components/SectionHeading';
import ImageGallery from '@/components/ImageGallery';

const eventPackages = [
  {
    id: 1,
    name: "Basic Event",
    price: "$1,200",
    description: "Perfect for small events up to 3 hours",
    features: [
      "3 hours of coverage",
      "1 photographer",
      "150+ edited digital images",
      "Online gallery",
      "Commercial usage rights",
      "48-hour rush delivery available (+$300)"
    ],
  },
  {
    id: 2,
    name: "Standard Event",
    price: "$2,200",
    description: "Our most popular package for medium-sized events",
    popular: true,
    features: [
      "6 hours of coverage",
      "1 photographer",
      "300+ edited digital images",
      "Online gallery",
      "Commercial usage rights",
      "Social media highlight set",
      "48-hour rush delivery available (+$300)"
    ],
  },
  {
    id: 3,
    name: "Premium Event",
    price: "$3,500",
    description: "Comprehensive coverage for large events",
    features: [
      "Full day coverage (up to 10 hours)",
      "2 photographers",
      "500+ edited digital images",
      "Online gallery",
      "Commercial usage rights",
      "Social media highlight set",
      "Same-day social media previews",
      "Custom USB drive with all images",
      "24-hour rush delivery available (+$500)"
    ],
  },
];

const portfolioImages = [
  {
    id: 1,
    url: "https://images.unsplash.com/photo-1540317580384-e5d43867caa6?w=800&h=600&fit=crop",
    alt: "Corporate conference"
  },
  {
    id: 2,
    url: "https://images.unsplash.com/photo-1511578314322-379afb476865?w=800&h=600&fit=crop",
    alt: "Award ceremony"
  },
  {
    id: 3,
    url: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=800&h=600&fit=crop",
    alt: "Company party"
  },
  {
    id: 4,
    url: "https://images.unsplash.com/photo-1528605248644-14dd04022da1?w=800&h=600&fit=crop",
    alt: "Team building event"
  },
  {
    id: 5,
    url: "https://images.unsplash.com/photo-1530023367847-a683933f4172?w=800&h=600&fit=crop",
    alt: "Birthday celebration"
  },
  {
    id: 6,
    url: "https://images.unsplash.com/photo-1516997121675-4c2d1684aa3e?w=800&h=600&fit=crop",
    alt: "Product launch event"
  },
];

const eventTypes = [
  {
    title: "Corporate Events",
    description: "Professional photography for conferences, meetings, team buildings, and corporate parties.",
    image: "https://images.unsplash.com/photo-1540317580384-e5d43867caa6?w=600&h=400&fit=crop"
  },
  {
    title: "Social Gatherings",
    description: "Capture special moments at birthdays, anniversaries, reunions, and holiday parties.",
    image: "https://images.unsplash.com/photo-1519671482749-fd09be7ccebf?w=600&h=400&fit=crop"
  },
  {
    title: "Product Launches",
    description: "Showcase your new products with professional event and product photography.",
    image: "https://images.unsplash.com/photo-1543269865-cbf427effbad?w=600&h=400&fit=crop"
  },
  {
    title: "Galas & Fundraisers",
    description: "Document your elegant charity events, galas, and fundraising activities.",
    image: "https://images.unsplash.com/photo-1511578314322-379afb476865?w=600&h=400&fit=crop"
  }
];

export default function EventServicesPage() {
  return (
    <>
      <PageBanner
        title="Event Photography"
        subtitle="Professional photography coverage for all types of events"
        backgroundImage="https://images.unsplash.com/photo-1540317580384-e5d43867caa6?w=1920&h=600&fit=crop"
      />

      {/* Service Overview */}
      <section className="py-20">
        <div className="container px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <h2 className="text-3xl font-bold mb-6">Event Photography Services</h2>
              <p className="text-muted-foreground mb-4">
                At MUZALA CREATIVE, we provide exceptional event photography services that capture the energy, connections, and key moments of your gatherings. Whether you're hosting a corporate conference, product launch, birthday celebration, or charity gala, our professional photographers will document your event with style and precision.
              </p>
              <p className="text-muted-foreground mb-4">
                Our approach combines candid documentary-style photography with strategic coverage of key moments, speakers, and interactions. We work discreetly to capture authentic moments without disrupting your event flow, while also providing directed shots when needed.
              </p>
              <p className="text-muted-foreground mb-6">
                With quick turnaround times and flexible delivery options, including rush delivery for time-sensitive events, we ensure you can share your event highlights promptly on social media, corporate communications, or marketing materials.
              </p>
              <div className="flex flex-wrap gap-4 mt-8">
                <Button asChild>
                  <Link to="/contact">Book Your Event</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/portfolio">View Portfolio</Link>
                </Button>
              </div>
            </div>
            <div className="order-1 md:order-2">
              <img 
                src="https://images.unsplash.com/photo-1511578314322-379afb476865?w=800&h=600&fit=crop" 
                alt="Corporate event photography" 
                className="rounded-lg shadow-lg w-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Event Types */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Event Types We Cover"
            subtitle="Specialized photography for various events and occasions"
          />
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
            {eventTypes.map((type, index) => (
              <div key={index} className="bg-background rounded-lg overflow-hidden shadow-sm">
                <div className="aspect-[4/3] overflow-hidden">
                  <img 
                    src={type.image} 
                    alt={type.title}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                  />
                </div>
                <div className="p-5">
                  <h3 className="text-xl font-semibold mb-2">{type.title}</h3>
                  <p className="text-muted-foreground">{type.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Advantages */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Why Choose Us for Your Event"
            subtitle="The MUZALA CREATIVE difference for your events"
          />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            {[
              {
                icon: <Clock className="h-10 w-10 text-primary" />,
                title: "Fast Turnaround",
                description: "Receive your edited photos within 3-5 business days, with rush options available for time-sensitive events."
              },
              {
                icon: <Zap className="h-10 w-10 text-primary" />,
                title: "Same-Day Previews",
                description: "Get select photos during or immediately after your event for instant social media sharing."
              },
              {
                icon: <Users className="h-10 w-10 text-primary" />,
                title: "Experienced Team",
                description: "Our photographers specialize in event photography with years of experience in various venues and lighting conditions."
              },
              {
                icon: <Globe className="h-10 w-10 text-primary" />,
                title: "Commercial Usage",
                description: "All packages include commercial usage rights for your marketing and promotional needs."
              },
              {
                icon: <Package className="h-10 w-10 text-primary" />,
                title: "Flexible Packages",
                description: "Customizable packages to fit events of any size, duration, and budget."
              },
              {
                icon: <CheckCircle className="h-10 w-10 text-primary" />,
                title: "Consistent Quality",
                description: "Professional equipment, backup systems, and post-processing ensure consistent high-quality results."
              }
            ].map((item, index) => (
              <div key={index} className="bg-muted/30 p-6 rounded-lg">
                <div className="mb-4">{item.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Event Photography Packages"
            subtitle="Choose the perfect coverage for your event"
          />
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            {eventPackages.map((pkg) => (
              <div 
                key={pkg.id} 
                className={`border rounded-lg overflow-hidden flex flex-col h-full bg-background ${
                  pkg.popular ? 'border-primary shadow-lg relative' : 'border-border'
                }`}
              >
                {pkg.popular && (
                  <div className="absolute top-6 right-0 bg-primary text-primary-foreground py-1 px-4 text-sm font-medium">
                    Most Popular
                  </div>
                )}
                <div className="p-6 bg-muted/30">
                  <div className="flex items-center mb-2">
                    <Package className="h-5 w-5 text-primary mr-2" />
                    <h3 className="text-2xl font-bold">{pkg.name}</h3>
                  </div>
                  <div className="text-3xl font-bold mb-2">{pkg.price}</div>
                  <p className="text-muted-foreground text-sm">{pkg.description}</p>
                </div>
                <div className="p-6 flex-grow">
                  <h4 className="font-medium mb-4">What's Included:</h4>
                  <ul className="space-y-3">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-6 pt-0">
                  <Button asChild className="w-full" variant={pkg.popular ? "default" : "outline"}>
                    <Link to="/contact">Book This Package</Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-8 text-muted-foreground">
            <p>Custom packages available for multi-day events, recurring events, or special requirements.</p>
          </div>
        </div>
      </section>

      {/* Portfolio Preview */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Event Photography Portfolio"
            subtitle="Examples of our event photography work"
          />
          <ImageGallery images={portfolioImages} />
          <div className="text-center mt-12">
            <Button asChild>
              <Link to="/portfolio">View Full Event Portfolio</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Our Event Coverage Process"
            subtitle="How we ensure successful event photography"
          />
          <div className="relative mt-20">
            {/* Timeline connector */}
            <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-primary/30 transform -translate-x-1/2 hidden md:block"></div>
            
            {/* Timeline items */}
            <div className="space-y-24">
              {[
                {
                  step: "1",
                  title: "Pre-Event Consultation",
                  description: "We discuss your event details, key moments to capture, schedule, and specific requirements.",
                  align: "right"
                },
                {
                  step: "2",
                  title: "Planning & Preparation",
                  description: "We create a custom shot list, visit the venue when possible, and prepare all equipment and backup gear.",
                  align: "left"
                },
                {
                  step: "3",
                  title: "Event Coverage",
                  description: "Our photographers arrive early, work discreetly to document your event, and coordinate with your team as needed.",
                  align: "right"
                },
                {
                  step: "4",
                  title: "Post-Production",
                  description: "We carefully select and professionally edit your images to ensure they look their absolute best.",
                  align: "left"
                },
                {
                  step: "5",
                  title: "Delivery",
                  description: "You receive your edited images through an online gallery, with download and sharing capabilities.",
                  align: "right"
                }
              ].map((item, index) => (
                <div key={index} className="relative">
                  <div className={`flex flex-col md:flex-row items-center ${item.align === "left" ? "md:flex-row-reverse" : ""}`}>
                    {/* Timeline dot */}
                    <div className="absolute left-1/2 transform -translate-x-1/2 md:static md:transform-none">
                      <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold relative z-10">
                        {item.step}
                      </div>
                    </div>
                    
                    {/* Content */}
                    <div className={`w-full md:w-1/2 mt-6 md:mt-0 text-center md:text-left ${item.align === "left" ? "md:text-right md:pr-8" : "md:pl-8"}`}>
                      <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                      <p className="text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial */}
      <section className="py-20 bg-secondary text-secondary-foreground">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">What Our Clients Say</h2>
            <div className="text-3xl italic mb-6">
              "MUZALA CREATIVE provided exceptional photography for our annual corporate gala. They were professional, unobtrusive, and the resulting images exceeded our expectations. We'll definitely be using them for all our future events."
            </div>
            <div className="font-medium">James Wilson</div>
            <div className="text-sm">Marketing Director, TechCorp International</div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Book Your Event?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Contact us today to check availability and discuss your event photography needs.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg">
              <Link to="/contact">Book Your Event</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/pricing">View All Pricing</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}