import { Link } from 'react-router-dom';
import { CheckCircle, Package, ShoppingBag, Building, Utensils, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PageBanner from '@/components/PageBanner';
import SectionHeading from '@/components/SectionHeading';
import ImageGallery from '@/components/ImageGallery';

const commercialPackages = [
  {
    id: 1,
    name: "Basic Commercial",
    price: "$1,500",
    description: "Product or basic commercial photography for small businesses",
    features: [
      "4-hour session",
      "Up to 10 products or setups",
      "Studio or on-location",
      "50 edited digital images",
      "Commercial usage rights",
      "Basic retouching",
      "Quick turnaround (1 week)"
    ],
  },
  {
    id: 2,
    name: "Professional Commercial",
    price: "$2,800",
    description: "Professional commercial photography for marketing campaigns",
    popular: true,
    features: [
      "Full day session (8 hours)",
      "Multiple products or setups",
      "Studio or on-location",
      "100+ edited digital images",
      "Commercial usage rights",
      "Advanced retouching",
      "Marketing-ready files",
      "Quick turnaround (1 week)",
      "Social media assets"
    ],
  },
  {
    id: 3,
    name: "Premium Commercial",
    price: "$4,500",
    description: "Premium commercial package for comprehensive brand photography",
    features: [
      "2 full-day sessions",
      "Unlimited products or setups",
      "Studio and on-location options",
      "200+ edited digital images",
      "Extended commercial usage rights",
      "Premium retouching",
      "Marketing-ready files",
      "Quick turnaround (1 week)",
      "Social media assets",
      "Art direction consultation"
    ],
  },
];

const portfolioImages = [
  {
    id: 1,
    url: "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=800&h=600&fit=crop",
    alt: "Watch product photography"
  },
  {
    id: 2,
    url: "https://images.unsplash.com/photo-1611930022073-84f3bb4caa4b?w=800&h=600&fit=crop",
    alt: "Food photography setup"
  },
  {
    id: 3,
    url: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800&h=600&fit=crop",
    alt: "Makeup product flat lay"
  },
  {
    id: 4,
    url: "https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=800&h=600&fit=crop",
    alt: "Office interior for real estate"
  },
  {
    id: 5,
    url: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&h=600&fit=crop",
    alt: "Fashion photography"
  },
  {
    id: 6,
    url: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&h=600&fit=crop",
    alt: "Headphone product photography"
  },
];

const commercialTypes = [
  {
    title: "Product Photography",
    description: "Showcase your products with high-quality images for e-commerce and marketing.",
    icon: <ShoppingBag className="h-10 w-10 text-primary" />,
    image: "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=600&h=400&fit=crop"
  },
  {
    title: "Real Estate & Architecture",
    description: "Stunning imagery of properties, interiors, and architectural details.",
    icon: <Building className="h-10 w-10 text-primary" />,
    image: "https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=600&h=400&fit=crop"
  },
  {
    title: "Food & Restaurant",
    description: "Appetizing food photography and restaurant atmosphere images.",
    icon: <Utensils className="h-10 w-10 text-primary" />,
    image: "https://images.unsplash.com/photo-1611930022073-84f3bb4caa4b?w=600&h=400&fit=crop"
  },
  {
    title: "Fashion & Lifestyle",
    description: "Dynamic fashion photography for lookbooks, campaigns, and marketing.",
    icon: <Camera className="h-10 w-10 text-primary" />,
    image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=600&h=400&fit=crop"
  }
];

export default function CommercialServicesPage() {
  return (
    <>
      <PageBanner
        title="Commercial Photography"
        subtitle="Professional photography services for products, brands, and businesses"
        backgroundImage="https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=1920&h=600&fit=crop"
      />

      {/* Service Overview */}
      <section className="py-20">
        <div className="container px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <h2 className="text-3xl font-bold mb-6">Commercial Photography Services</h2>
              <p className="text-muted-foreground mb-4">
                At MUZALA CREATIVE, we provide professional commercial photography services designed to elevate your brand, showcase your products, and enhance your marketing materials. In today's visually-driven marketplace, high-quality imagery is essential for making a lasting impression and driving sales.
              </p>
              <p className="text-muted-foreground mb-4">
                Our commercial photography services cover everything from product photography and real estate imaging to food photography and fashion shoots. With meticulous attention to detail, expert lighting techniques, and creative composition, we create compelling visuals that help your business stand out.
              </p>
              <p className="text-muted-foreground mb-6">
                Every commercial project begins with understanding your brand identity, target audience, and marketing goals, ensuring that the images we create align perfectly with your vision and business objectives.
              </p>
              <div className="flex flex-wrap gap-4 mt-8">
                <Button asChild>
                  <Link to="/contact">Discuss Your Project</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/portfolio">View Portfolio</Link>
                </Button>
              </div>
            </div>
            <div className="order-1 md:order-2">
              <img 
                src="https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=800&h=600&fit=crop" 
                alt="Product photography setup" 
                className="rounded-lg shadow-lg w-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Commercial Types */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Commercial Photography Types"
            subtitle="Specialized commercial photography services for various business needs"
          />
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
            {commercialTypes.map((type, index) => (
              <div key={index} className="bg-background rounded-lg overflow-hidden shadow-sm flex flex-col">
                <div className="aspect-[4/3] overflow-hidden">
                  <img 
                    src={type.image} 
                    alt={type.title}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                  />
                </div>
                <div className="p-5 flex-grow">
                  <div className="flex items-center gap-3 mb-3">
                    {type.icon}
                    <h3 className="text-xl font-semibold">{type.title}</h3>
                  </div>
                  <p className="text-muted-foreground">{type.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Why Choose Us for Commercial Photography"
            subtitle="What sets our commercial photography services apart"
          />
          <div className="grid md:grid-cols-2 gap-8 mt-12">
            {[
              {
                title: "Technical Excellence",
                description: "Our photographers use top-of-the-line equipment and advanced lighting techniques to create exceptional images with perfect exposure, sharpness, and color accuracy."
              },
              {
                title: "Brand Alignment",
                description: "We take time to understand your brand identity and target audience, ensuring that every image we create aligns with your overall marketing strategy and goals."
              },
              {
                title: "Attention to Detail",
                description: "From perfect product positioning to careful post-processing, we focus on the small details that make a big difference in commercial photography."
              },
              {
                title: "Creative Direction",
                description: "Our team brings creative concepts and artistic vision to every commercial project, helping your brand stand out in a crowded marketplace."
              },
              {
                title: "Versatility",
                description: "With experience across multiple commercial photography niches, we can adapt our approach to suit various products, properties, and brand styles."
              },
              {
                title: "Marketing Expertise",
                description: "Beyond photography, we understand marketing principles and create images specifically designed to drive engagement and conversions."
              }
            ].map((item, index) => (
              <div key={index} className="flex">
                <div className="mr-4 mt-1">
                  <CheckCircle className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                  <p className="text-muted-foreground">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Commercial Photography Packages"
            subtitle="Professional packages for businesses of all sizes"
          />
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            {commercialPackages.map((pkg) => (
              <div 
                key={pkg.id} 
                className={`border rounded-lg overflow-hidden flex flex-col h-full bg-background ${
                  pkg.popular ? 'border-primary shadow-lg relative' : 'border-border'
                }`}
              >
                {pkg.popular && (
                  <div className="absolute top-6 right-0 bg-primary text-primary-foreground py-1 px-4 text-sm font-medium">
                    Most Popular
                  </div>
                )}
                <div className="p-6 bg-muted/30">
                  <div className="flex items-center mb-2">
                    <Package className="h-5 w-5 text-primary mr-2" />
                    <h3 className="text-2xl font-bold">{pkg.name}</h3>
                  </div>
                  <div className="text-3xl font-bold mb-2">{pkg.price}</div>
                  <p className="text-muted-foreground text-sm">{pkg.description}</p>
                </div>
                <div className="p-6 flex-grow">
                  <h4 className="font-medium mb-4">What's Included:</h4>
                  <ul className="space-y-3">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-6 pt-0">
                  <Button asChild className="w-full" variant={pkg.popular ? "default" : "outline"}>
                    <Link to="/contact">Book This Package</Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-8 text-muted-foreground">
            <p>Need something custom? <Link to="/contact" className="text-primary underline">Contact us</Link> for a tailored commercial photography quote.</p>
          </div>
        </div>
      </section>

      {/* Portfolio Preview */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Commercial Photography Portfolio"
            subtitle="Examples of our commercial photography work"
          />
          <ImageGallery images={portfolioImages} />
          <div className="text-center mt-12">
            <Button asChild>
              <Link to="/portfolio">View Full Commercial Portfolio</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Our Commercial Photography Process"
            subtitle="How we approach commercial photography projects"
          />
          <div className="grid md:grid-cols-2 gap-12 mt-12">
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold mb-3">1. Consultation & Planning</h3>
                <p className="text-muted-foreground">
                  We begin with a thorough consultation to understand your brand, target audience, and specific goals for the images. This includes discussing products, locations, styling, and how the photos will be used in your marketing.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-3">2. Creative Direction</h3>
                <p className="text-muted-foreground">
                  Our team develops a creative concept that aligns with your brand identity and marketing objectives. This includes mood boards, styling recommendations, and shot lists to ensure we capture everything needed.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-3">3. Production & Photography</h3>
                <p className="text-muted-foreground">
                  On shoot day, our professional team handles everything from lighting setup to product arrangement. Whether in our studio or on location, we work methodically to capture perfect images of your products or services.
                </p>
              </div>
            </div>
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold mb-3">4. Selection & Editing</h3>
                <p className="text-muted-foreground">
                  After the shoot, we curate the best images and apply professional editing techniques to enhance colors, adjust lighting, and ensure consistency across the entire set. This includes precise retouching for product photography.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-3">5. Review & Refinement</h3>
                <p className="text-muted-foreground">
                  You'll have the opportunity to review the edited images and request any specific adjustments or additional retouching to ensure the final results match your vision perfectly.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-3">6. Delivery & Implementation</h3>
                <p className="text-muted-foreground">
                  Once approved, we deliver your images in multiple formats optimized for various marketing channels—web, print, social media, and more. We can also provide guidance on how to best implement the images in your marketing.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Client Success Story */}
      <section className="py-20 bg-secondary text-secondary-foreground">
        <div className="container px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4">Client Success Story</h2>
              <h3 className="text-xl mb-6">How our product photography increased online sales by 32%</h3>
              <blockquote className="text-lg italic mb-6">
                "MUZALA CREATIVE's product photography completely transformed our online store. The images highlighted our products' quality and features in ways our previous photos never did. Within three months of updating our product images, we saw a 32% increase in online sales and a significant reduction in return rates."
              </blockquote>
              <div className="font-medium">Daniel Clark</div>
              <div className="text-sm">Marketing Manager, LuxeStyle</div>
            </div>
            <div className="flex justify-center">
              <img 
                src="https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=500&h=500&fit=crop" 
                alt="Product photography example" 
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Industries Served */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Industries We Serve"
            subtitle="Commercial photography solutions for diverse business sectors"
          />
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 mt-12">
            {[
              "Retail & E-commerce",
              "Food & Beverage",
              "Real Estate",
              "Fashion & Apparel",
              "Beauty & Cosmetics",
              "Technology",
              "Hospitality",
              "Furniture & Home Goods",
              "Jewelry & Accessories",
              "Professional Services",
              "Health & Wellness",
              "Manufacturing"
            ].map((industry, index) => (
              <div 
                key={index} 
                className="bg-muted/30 py-4 px-3 rounded-lg text-center font-medium hover:bg-muted/50 transition-colors"
              >
                {industry}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Commercial Photography FAQs"
            subtitle="Answers to common questions about our commercial services"
          />
          <div className="grid md:grid-cols-2 gap-x-12 gap-y-8 mt-12">
            {[
              {
                question: "What rights do I have to the photos?",
                answer: "All our commercial packages include standard commercial usage rights, allowing you to use the images for your marketing, website, social media, and promotional materials. Extended licensing for specific uses can be arranged if needed."
              },
              {
                question: "Can you match our brand's existing visual style?",
                answer: "Absolutely! We'll study your brand guidelines and existing imagery to ensure our photos seamlessly integrate with your visual identity. Consistency is key for effective branding."
              },
              {
                question: "How quickly can you deliver commercial projects?",
                answer: "Our standard turnaround time is one week for most commercial projects. Rush delivery options are available for time-sensitive campaigns, with some projects deliverable within 48 hours."
              },
              {
                question: "Do you provide props and styling for product photography?",
                answer: "Yes, we offer styling services and have a collection of props suitable for various product categories. For specialized products, we can source specific props or you're welcome to provide your own."
              },
              {
                question: "Can you shoot at our business location?",
                answer: "Yes, we offer on-location photography services for businesses throughout the area. This is ideal for real estate, restaurants, corporate environments, and businesses wanting to showcase their facilities."
              },
              {
                question: "Do you offer video services along with photography?",
                answer: "Yes, we offer commercial videography services that can be bundled with photography for comprehensive visual content creation. Please inquire for specific video service details and pricing."
              }
            ].map((faq, index) => (
              <div key={index} className="mb-6">
                <h4 className="text-lg font-semibold mb-2">{faq.question}</h4>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Elevate Your Brand?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Contact us today to discuss your commercial photography needs and how we can help showcase your products and services.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg">
              <Link to="/contact">Request a Quote</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/portfolio">View Our Work</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}