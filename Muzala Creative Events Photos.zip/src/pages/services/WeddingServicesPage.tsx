import { Link } from 'react-router-dom';
import { CheckCircle, Package, Camera, Clock, Heart, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PageBanner from '@/components/PageBanner';
import SectionHeading from '@/components/SectionHeading';
import ImageGallery from '@/components/ImageGallery';

const weddingPackages = [
  {
    id: 1,
    name: "Essential",
    price: "$2,500",
    description: "Perfect for intimate weddings and elopements",
    features: [
      "6 hours of coverage",
      "1 photographer",
      "300+ edited digital images",
      "Online gallery",
      "Print release",
      "Engagement session"
    ],
  },
  {
    id: 2,
    name: "Premium",
    price: "$3,800",
    description: "Our most popular package for medium to large weddings",
    popular: true,
    features: [
      "10 hours of coverage",
      "2 photographers",
      "600+ edited digital images",
      "Online gallery",
      "Print release",
      "Engagement session",
      "Wedding album (10x10, 20 pages)",
      "Second day coverage (rehearsal dinner)"
    ],
  },
  {
    id: 3,
    name: "Luxury",
    price: "$5,500",
    description: "The ultimate wedding photography experience",
    features: [
      "Full day coverage (up to 12 hours)",
      "2 photographers",
      "800+ edited digital images",
      "Online gallery",
      "Print release",
      "Engagement session",
      "Deluxe wedding album (12x12, 30 pages)",
      "Two parent albums (8x8, 20 pages)",
      "Second day coverage (rehearsal dinner)",
      "Drone aerial photography",
      "Same-day highlight slideshow"
    ],
  },
];

const portfolioImages = [
  {
    id: 1,
    url: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=800&h=600&fit=crop",
    alt: "Bride and groom laughing"
  },
  {
    id: 2,
    url: "https://images.unsplash.com/photo-1519741347686-c1e0aadf4611?w=800&h=600&fit=crop",
    alt: "Couple's first dance"
  },
  {
    id: 3,
    url: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&h=600&fit=crop",
    alt: "Wedding rings close-up"
  },
  {
    id: 4,
    url: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?w=800&h=600&fit=crop",
    alt: "Wedding venue decoration"
  },
  {
    id: 5,
    url: "https://images.unsplash.com/photo-1507504031003-ba985c5c963f?w=800&h=600&fit=crop",
    alt: "Bridal preparation"
  },
  {
    id: 6,
    url: "https://images.unsplash.com/photo-1606800052052-a08af7148866?w=800&h=600&fit=crop",
    alt: "Wedding ceremony"
  },
];

export default function WeddingServicesPage() {
  return (
    <>
      <PageBanner
        title="Wedding Photography"
        subtitle="Capturing your special day with artistry and emotion"
        backgroundImage="https://images.unsplash.com/photo-1537907510278-f4adc3d15261?w=1920&h=600&fit=crop"
      />

      {/* Service Overview */}
      <section className="py-20">
        <div className="container px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Telling Your Love Story</h2>
              <p className="text-muted-foreground mb-4">
                Your wedding day is one of the most important days of your life, filled with precious moments and emotions that deserve to be preserved forever. At MUZALA CREATIVE, we specialize in capturing these moments with a perfect blend of candid photojournalism and artfully directed portraits.
              </p>
              <p className="text-muted-foreground mb-4">
                Our approach to wedding photography is both unobtrusive and engaging, allowing us to document genuine moments while also creating stunning portraits that you'll treasure for generations. We focus not just on the key events, but also on the subtle interactions, emotions, and details that make your wedding uniquely yours.
              </p>
              <p className="text-muted-foreground mb-6">
                From the nervous excitement as you prepare, to the tears during the ceremony, to the joy and celebration at the reception - we'll be there to document it all with creativity, professionalism, and attention to detail.
              </p>
              <div className="flex flex-wrap gap-4 mt-8">
                <Button asChild>
                  <Link to="/contact">Book Your Wedding</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/portfolio">View Portfolio</Link>
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <img 
                  src="https://images.unsplash.com/photo-1583939003579-730e3918a45a?w=500&h=750&fit=crop"
                  alt="Bride preparation"
                  className="w-full h-auto rounded-lg shadow-lg"
                />
                <img 
                  src="https://images.unsplash.com/photo-1595555723423-9d892a5541aa?w=500&h=333&fit=crop"
                  alt="Wedding rings"
                  className="w-full h-auto rounded-lg shadow-lg"
                />
              </div>
              <div className="pt-8">
                <img 
                  src="https://images.unsplash.com/photo-1606216794074-735e91daa580?w=500&h=750&fit=crop"
                  alt="Wedding couple portrait"
                  className="w-full h-auto rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Why Choose Us for Your Wedding"
            subtitle="What makes our wedding photography service special"
          />
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
            {[
              {
                icon: <Camera className="h-10 w-10 text-primary" />,
                title: "Experienced Team",
                description: "With over 500 weddings photographed, our team knows how to anticipate and capture key moments."
              },
              {
                icon: <Heart className="h-10 w-10 text-primary" />,
                title: "Personalized Approach",
                description: "We take time to understand your vision, style preferences, and the unique aspects of your relationship."
              },
              {
                icon: <Clock className="h-10 w-10 text-primary" />,
                title: "Timely Delivery",
                description: "Receive your beautifully edited images within 3-4 weeks of your wedding day."
              },
              {
                icon: <Users className="h-10 w-10 text-primary" />,
                title: "Multiple Photographers",
                description: "Multiple perspectives ensure no moment is missed during your special day."
              }
            ].map((item, index) => (
              <div key={index} className="bg-background p-6 rounded-lg shadow-sm">
                <div className="mb-4">{item.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Wedding Photography Packages"
            subtitle="Choose the perfect package for your special day"
          />
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            {weddingPackages.map((pkg) => (
              <div 
                key={pkg.id} 
                className={`border rounded-lg overflow-hidden flex flex-col h-full ${
                  pkg.popular ? 'border-primary shadow-lg relative' : 'border-border'
                }`}
              >
                {pkg.popular && (
                  <div className="absolute top-6 right-0 bg-primary text-primary-foreground py-1 px-4 text-sm font-medium">
                    Most Popular
                  </div>
                )}
                <div className="p-6 bg-muted/30">
                  <div className="flex items-center mb-2">
                    <Package className="h-5 w-5 text-primary mr-2" />
                    <h3 className="text-2xl font-bold">{pkg.name}</h3>
                  </div>
                  <div className="text-3xl font-bold mb-2">{pkg.price}</div>
                  <p className="text-muted-foreground text-sm">{pkg.description}</p>
                </div>
                <div className="p-6 flex-grow">
                  <h4 className="font-medium mb-4">What's Included:</h4>
                  <ul className="space-y-3">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-6 pt-0">
                  <Button asChild className="w-full" variant={pkg.popular ? "default" : "outline"}>
                    <Link to="/contact">Book This Package</Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-8 text-muted-foreground">
            <p>All packages can be customized to meet your specific needs. Contact us for custom quotes.</p>
          </div>
        </div>
      </section>

      {/* Portfolio Preview */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Wedding Portfolio"
            subtitle="A glimpse into our wedding photography work"
          />
          <ImageGallery images={portfolioImages} />
          <div className="text-center mt-12">
            <Button asChild>
              <Link to="/portfolio">View Full Wedding Portfolio</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Frequently Asked Wedding Questions"
            subtitle="Common questions about our wedding photography services"
          />
          <div className="grid md:grid-cols-2 gap-x-12 gap-y-8 mt-12">
            {[
              {
                question: "How far in advance should I book my wedding?",
                answer: "We recommend booking 9-12 months in advance for peak wedding season dates (May-October). For off-season weddings, 6 months is usually sufficient, but popular dates can book up quickly regardless of season."
              },
              {
                question: "Do you offer engagement sessions?",
                answer: "Yes, all our wedding packages include a complimentary engagement session. This is a great way for us to get to know each other before the wedding day and for you to get comfortable in front of the camera."
              },
              {
                question: "How many photographers will be at my wedding?",
                answer: "Our Essential package includes one photographer, while our Premium and Luxury packages include two photographers to capture multiple angles and ensure comprehensive coverage of your day."
              },
              {
                question: "What happens if it rains on our wedding day?",
                answer: "We're well-prepared for all weather conditions! We always scout backup locations ahead of time and bring appropriate equipment for rainy conditions. Sometimes, rainy day photos can be even more romantic and unique!"
              },
              {
                question: "Do you photograph destination weddings?",
                answer: "Absolutely! We love traveling for weddings. Destination wedding packages include travel and accommodation costs, which we'll discuss during consultation."
              },
              {
                question: "How do we receive our photos?",
                answer: "All images are delivered through a beautiful, user-friendly online gallery where you can download high-resolution files, share with family and friends, and order prints directly. Physical products like albums are delivered to your home."
              }
            ].map((faq, index) => (
              <div key={index} className="mb-6">
                <h4 className="text-lg font-semibold mb-2">{faq.question}</h4>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial */}
      <section className="py-20 bg-secondary text-secondary-foreground">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">What Our Wedding Clients Say</h2>
            <div className="text-3xl italic mb-6">
              "MUZALA CREATIVE made our wedding day even more special with their talent and professionalism. They captured every emotion and detail perfectly, and our album is a beautiful treasure we'll cherish forever."
            </div>
            <div className="font-medium">Jessica & David Thompson</div>
            <div className="text-sm">Married June 2025</div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Book Your Wedding?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Contact us today to check our availability for your special day.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg">
              <Link to="/contact">Book Your Wedding</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/pricing">View All Pricing</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}