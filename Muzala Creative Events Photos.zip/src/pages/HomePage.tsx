import { ArrowRight, Camera, Calendar, Award, Heart, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import HeroSection from '@/components/HeroSection';
import SectionHeading from '@/components/SectionHeading';
import ServiceCard from '@/components/ServiceCard';
import TestimonialCard from '@/components/TestimonialCard';
import ImageGallery from '@/components/ImageGallery';

const services = [
  {
    id: 1,
    title: "Wedding Photography",
    description: "Capture your special day with artistic and emotional photography that tells your love story.",
    image: "https://images.unsplash.com/photo-1519741497674-611481863552?w=800&h=600&fit=crop",
    link: "/services/wedding"
  },
  {
    id: 2,
    title: "Event Coverage",
    description: "Professional photography for corporate events, parties, and special celebrations.",
    image: "https://images.unsplash.com/photo-1540317580384-e5d43867caa6?w=800&h=600&fit=crop",
    link: "/services/events"
  },
  {
    id: 3,
    title: "Portrait Sessions",
    description: "Stunning portrait photography that captures personality and creates timeless images.",
    image: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=800&h=600&fit=crop",
    link: "/services/portraits"
  },
  {
    id: 4,
    title: "Commercial Photography",
    description: "High-quality commercial photography for brands, products, and marketing campaigns.",
    image: "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=800&h=600&fit=crop",
    link: "/services/commercial"
  }
];

const testimonials = [
  {
    id: 1,
    name: "Sarah & Michael",
    role: "Wedding Clients",
    quote: "MUZALA CREATIVE captured our wedding day perfectly. The photos are absolutely stunning and captured all the emotions of our special day.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1531747118685-ca8fa6e08806?w=100&h=100&fit=crop"
  },
  {
    id: 2,
    name: "James Wilson",
    role: "Corporate Event",
    quote: "Professional, punctual, and produced amazing photos for our corporate event. Our team was extremely impressed with the quality.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop"
  },
  {
    id: 3,
    name: "Emma Rodriguez",
    role: "Portrait Client",
    quote: "I've never felt so comfortable during a photoshoot. The photos are beautiful and really captured my personality. Highly recommend!",
    rating: 5,
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop"
  }
];

const featuredImages = [
  {
    id: 1,
    url: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=800&h=600&fit=crop",
    alt: "Wedding celebration moment"
  },
  {
    id: 2,
    url: "https://images.unsplash.com/photo-1551334787-d61fabf9a10d?w=800&h=600&fit=crop",
    alt: "Corporate event photography"
  },
  {
    id: 3,
    url: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=800&h=600&fit=crop",
    alt: "Portrait photography session"
  },
  {
    id: 4,
    url: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=800&h=600&fit=crop",
    alt: "Product photography setup"
  },
  {
    id: 5,
    url: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&h=600&fit=crop",
    alt: "Fashion photography"
  },
  {
    id: 6,
    url: "https://images.unsplash.com/photo-1519741347686-c1e0aadf4611?w=800&h=600&fit=crop",
    alt: "Wedding couple portrait"
  }
];

const stats = [
  { id: 1, value: "10+", label: "Years Experience", icon: <Camera className="h-6 w-6 text-primary" /> },
  { id: 2, value: "500+", label: "Events Covered", icon: <Calendar className="h-6 w-6 text-primary" /> },
  { id: 3, value: "200+", label: "Happy Clients", icon: <Users className="h-6 w-6 text-primary" /> },
  { id: 4, value: "50+", label: "Awards Won", icon: <Award className="h-6 w-6 text-primary" /> },
  { id: 5, value: "100%", label: "Satisfaction", icon: <Heart className="h-6 w-6 text-primary" /> }
];

function HomePage() {
  return (
    <>
      {/* Hero Section */}
      <HeroSection
        title="Capturing Life's Beautiful Moments"
        subtitle="Professional photography services for weddings, events, portraits, and commercial projects"
        backgroundImage="https://images.unsplash.com/photo-1502444330042-d1a1ddf9bb5b?w=1920&h=1080&fit=crop"
        minHeight="min-h-screen"
      >
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
          <Button asChild size="lg">
            <Link to="/portfolio">View Portfolio</Link>
          </Button>
          <Button asChild variant="outline" className="bg-transparent text-white border-white hover:bg-white/20" size="lg">
            <Link to="/contact">Book a Session</Link>
          </Button>
        </div>
      </HeroSection>

      {/* About Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 tracking-tight">
                Passionate About Capturing Perfect Moments
              </h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                MUZALA CREATIVE is a premier photography studio specializing in weddings, events, portraits, and commercial photography. 
                With over 10 years of experience, our team of professional photographers is dedicated to capturing your special moments 
                with creativity, passion, and technical excellence.
              </p>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                We believe that every image tells a story, and we're committed to telling yours in the most authentic and beautiful way possible.
              </p>
              <Button asChild>
                <Link to="/about">
                  Learn More About Us
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <img 
                  src="https://images.unsplash.com/photo-1566939320723-a5f47a2cd8a9?w=500&h=750&fit=crop"
                  alt="Photographer in action"
                  className="w-full h-auto rounded-lg shadow-lg"
                />
                <img 
                  src="https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=500&h=333&fit=crop"
                  alt="Camera equipment"
                  className="w-full h-auto rounded-lg shadow-lg"
                />
              </div>
              <div className="pt-8">
                <img 
                  src="https://images.unsplash.com/photo-1452587925148-ce544e77e70d?w=500&h=750&fit=crop"
                  alt="Photography result"
                  className="w-full h-auto rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Our Photography Services"
            subtitle="Specialized photography services tailored to your unique needs"
          />
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service) => (
              <ServiceCard
                key={service.id}
                title={service.title}
                description={service.description}
                image={service.image}
                link={service.link}
              />
            ))}
          </div>
          <div className="text-center mt-12">
            <Button asChild variant="outline" size="lg">
              <Link to="/services">View All Services</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container px-4">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6 text-center">
            {stats.map((stat) => (
              <div key={stat.id} className="p-4">
                <div className="flex justify-center mb-2">{stat.icon}</div>
                <div className="text-3xl md:text-4xl font-bold mb-1">{stat.value}</div>
                <div className="text-sm text-primary-foreground/80">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Preview */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Featured Work"
            subtitle="A glimpse into our diverse photography portfolio"
          />
          <ImageGallery images={featuredImages} />
          <div className="text-center mt-12">
            <Button asChild size="lg">
              <Link to="/portfolio">View Full Portfolio</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="What Our Clients Say"
            subtitle="Don't just take our word for it, hear from our happy clients"
          />
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial) => (
              <TestimonialCard
                key={testimonial.id}
                name={testimonial.name}
                role={testimonial.role}
                quote={testimonial.quote}
                rating={testimonial.rating}
                image={testimonial.image}
              />
            ))}
          </div>
          <div className="text-center mt-12">
            <Button asChild variant="outline">
              <Link to="/testimonials">Read More Testimonials</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-secondary text-secondary-foreground">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Capture Your Special Moments?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Let's create beautiful memories together. Contact us today to book your photography session.
          </p>
          <Button asChild size="lg" className="bg-primary hover:bg-primary/90">
            <Link to="/contact">Get in Touch</Link>
          </Button>
        </div>
      </section>
    </>
  );
}

export default HomePage;