import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter } from "lucide-react";
import PageBanner from "@/components/PageBanner";
import ImageGallery from "@/components/ImageGallery";
import SectionHeading from "@/components/SectionHeading";

// Gallery images
const allGalleryImages = [
  // Wedding Images
  {
    id: 1,
    url: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=800&h=600&fit=crop",
    alt: "Bride and groom laughing",
    category: "weddings",
    tags: ["ceremony", "couple", "outdoor"]
  },
  {
    id: 2,
    url: "https://images.unsplash.com/photo-1519741347686-c1e0aadf4611?w=800&h=600&fit=crop",
    alt: "Couple's first dance",
    category: "weddings",
    tags: ["reception", "couple", "indoor"]
  },
  {
    id: 3,
    url: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&h=600&fit=crop",
    alt: "Wedding rings close-up",
    category: "weddings",
    tags: ["details", "macro", "indoor"]
  },
  {
    id: 4,
    url: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?w=800&h=600&fit=crop",
    alt: "Wedding venue decoration",
    category: "weddings",
    tags: ["venue", "details", "indoor"]
  },
  {
    id: 5,
    url: "https://images.unsplash.com/photo-1507504031003-ba985c5c963f?w=800&h=600&fit=crop",
    alt: "Bridal preparation",
    category: "weddings",
    tags: ["preparation", "portrait", "indoor"]
  },
  {
    id: 6,
    url: "https://images.unsplash.com/photo-1606800052052-a08af7148866?w=800&h=600&fit=crop",
    alt: "Wedding ceremony",
    category: "weddings",
    tags: ["ceremony", "venue", "guests"]
  },
  {
    id: 7,
    url: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?w=800&h=600&fit=crop",
    alt: "Bride portrait",
    category: "weddings",
    tags: ["portrait", "bride", "indoor"]
  },
  {
    id: 8,
    url: "https://images.unsplash.com/photo-1606216794074-735e91daa580?w=800&h=600&fit=crop",
    alt: "Wedding couple outdoor portrait",
    category: "weddings",
    tags: ["portrait", "couple", "outdoor"]
  },
  
  // Event Images
  {
    id: 9,
    url: "https://images.unsplash.com/photo-1540317580384-e5d43867caa6?w=800&h=600&fit=crop",
    alt: "Corporate conference",
    category: "events",
    tags: ["corporate", "conference", "indoor"]
  },
  {
    id: 10,
    url: "https://images.unsplash.com/photo-1511578314322-379afb476865?w=800&h=600&fit=crop",
    alt: "Award ceremony",
    category: "events",
    tags: ["corporate", "ceremony", "indoor"]
  },
  {
    id: 11,
    url: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=800&h=600&fit=crop",
    alt: "Company party",
    category: "events",
    tags: ["corporate", "party", "indoor"]
  },
  {
    id: 12,
    url: "https://images.unsplash.com/photo-1528605248644-14dd04022da1?w=800&h=600&fit=crop",
    alt: "Team building event",
    category: "events",
    tags: ["corporate", "team", "outdoor"]
  },
  {
    id: 13,
    url: "https://images.unsplash.com/photo-1530023367847-a683933f4172?w=800&h=600&fit=crop",
    alt: "Birthday celebration",
    category: "events",
    tags: ["birthday", "party", "indoor"]
  },
  {
    id: 14,
    url: "https://images.unsplash.com/photo-1516997121675-4c2d1684aa3e?w=800&h=600&fit=crop",
    alt: "Product launch event",
    category: "events",
    tags: ["corporate", "product", "indoor"]
  },
  
  // Portrait Images
  {
    id: 15,
    url: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=800&h=600&fit=crop",
    alt: "Female portrait with natural light",
    category: "portraits",
    tags: ["female", "natural", "outdoor"]
  },
  {
    id: 16,
    url: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=800&h=600&fit=crop",
    alt: "Male portrait with glasses",
    category: "portraits",
    tags: ["male", "business", "indoor"]
  },
  {
    id: 17,
    url: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=800&h=600&fit=crop",
    alt: "Professional headshot of young woman",
    category: "portraits",
    tags: ["female", "business", "indoor"]
  },
  {
    id: 18,
    url: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=800&h=600&fit=crop",
    alt: "Smiling man portrait",
    category: "portraits",
    tags: ["male", "casual", "indoor"]
  },
  {
    id: 19,
    url: "https://images.unsplash.com/photo-1527203561188-dae1bc1a417f?w=800&h=600&fit=crop",
    alt: "Family portrait outdoors",
    category: "portraits",
    tags: ["family", "group", "outdoor"]
  },
  {
    id: 20,
    url: "https://images.unsplash.com/photo-1610631787813-9eeb1a2386cc?w=800&h=600&fit=crop",
    alt: "Senior portrait session",
    category: "portraits",
    tags: ["senior", "female", "outdoor"]
  },
  
  // Commercial Images
  {
    id: 21,
    url: "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=800&h=600&fit=crop",
    alt: "Watch product photography",
    category: "commercial",
    tags: ["product", "luxury", "studio"]
  },
  {
    id: 22,
    url: "https://images.unsplash.com/photo-1611930022073-84f3bb4caa4b?w=800&h=600&fit=crop",
    alt: "Food photography setup",
    category: "commercial",
    tags: ["food", "restaurant", "studio"]
  },
  {
    id: 23,
    url: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800&h=600&fit=crop",
    alt: "Makeup product flat lay",
    category: "commercial",
    tags: ["product", "beauty", "studio"]
  },
  {
    id: 24,
    url: "https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=800&h=600&fit=crop",
    alt: "Office interior for real estate",
    category: "commercial",
    tags: ["real-estate", "interior", "indoor"]
  },
  {
    id: 25,
    url: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&h=600&fit=crop",
    alt: "Fashion photography",
    category: "commercial",
    tags: ["fashion", "model", "studio"]
  },
  {
    id: 26,
    url: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&h=600&fit=crop",
    alt: "Headphone product photography",
    category: "commercial",
    tags: ["product", "electronics", "studio"]
  },
];

// Categories and tags for filters
const categories = [
  { value: "all", label: "All Categories" },
  { value: "weddings", label: "Weddings" },
  { value: "events", label: "Events" },
  { value: "portraits", label: "Portraits" },
  { value: "commercial", label: "Commercial" },
];

// Get unique tags from all images
const uniqueTags = [...new Set(allGalleryImages.flatMap(img => img.tags))].sort();
const tags = [
  { value: "all", label: "All Tags" },
  ...uniqueTags.map(tag => ({ value: tag, label: tag.charAt(0).toUpperCase() + tag.slice(1) }))
];

export default function GalleryPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedTag, setSelectedTag] = useState("all");
  const [filteredImages, setFilteredImages] = useState(allGalleryImages);
  const [showFilters, setShowFilters] = useState(false);

  // Filter images based on search term, category, and tag
  useEffect(() => {
    let filtered = allGalleryImages;
    
    // Filter by search term
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      filtered = filtered.filter(img => 
        img.alt.toLowerCase().includes(searchLower) || 
        img.tags.some(tag => tag.toLowerCase().includes(searchLower))
      );
    }
    
    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter(img => img.category === selectedCategory);
    }
    
    // Filter by tag
    if (selectedTag !== "all") {
      filtered = filtered.filter(img => img.tags.includes(selectedTag));
    }
    
    setFilteredImages(filtered);
  }, [searchTerm, selectedCategory, selectedTag]);

  return (
    <>
      <PageBanner
        title="Image Gallery"
        subtitle="Browse through our extensive collection of high-quality photography"
        backgroundImage="https://images.unsplash.com/photo-1557682224-5b8590cd9ec5?w=1920&h=600&fit=crop"
      />

      {/* Gallery Controls */}
      <section className="py-10">
        <div className="container px-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="relative w-full md:w-72">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                type="text"
                placeholder="Search gallery..."
                className="pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-3">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2"
              >
                <Filter className="h-4 w-4" />
                {showFilters ? "Hide Filters" : "Show Filters"}
              </Button>
              <div className="text-sm text-muted-foreground">
                Showing {filteredImages.length} of {allGalleryImages.length} images
              </div>
            </div>
          </div>
          
          {/* Filters */}
          {showFilters && (
            <div className="mt-4 p-4 border rounded-lg bg-muted/30">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Category</label>
                  <select 
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                  >
                    {categories.map((category) => (
                      <option key={category.value} value={category.value}>
                        {category.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Tag</label>
                  <select 
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                    value={selectedTag}
                    onChange={(e) => setSelectedTag(e.target.value)}
                  >
                    {tags.map((tag) => (
                      <option key={tag.value} value={tag.value}>
                        {tag.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="mt-4 flex justify-end">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => {
                    setSelectedCategory("all");
                    setSelectedTag("all");
                    setSearchTerm("");
                  }}
                >
                  Reset Filters
                </Button>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-10">
        <div className="container px-4">
          {filteredImages.length > 0 ? (
            <ImageGallery images={filteredImages} columns={4} />
          ) : (
            <div className="text-center py-20 bg-muted/30 rounded-lg">
              <h3 className="text-2xl font-semibold mb-2">No Images Found</h3>
              <p className="text-muted-foreground mb-6">
                No images match your current search criteria. Try adjusting your filters.
              </p>
              <Button 
                onClick={() => {
                  setSelectedCategory("all");
                  setSelectedTag("all");
                  setSearchTerm("");
                }}
              >
                Reset All Filters
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Categories Quick Links */}
      <section className="py-16 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Explore by Category"
            subtitle="Jump directly to your favorite type of photography"
          />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            {[
              {
                name: "Wedding Photography",
                image: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=600&h=400&fit=crop",
                action: () => {
                  setSelectedCategory("weddings");
                  setSelectedTag("all");
                  setSearchTerm("");
                  setShowFilters(true);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              },
              {
                name: "Event Photography",
                image: "https://images.unsplash.com/photo-1540317580384-e5d43867caa6?w=600&h=400&fit=crop",
                action: () => {
                  setSelectedCategory("events");
                  setSelectedTag("all");
                  setSearchTerm("");
                  setShowFilters(true);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              },
              {
                name: "Portrait Photography",
                image: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=600&h=400&fit=crop",
                action: () => {
                  setSelectedCategory("portraits");
                  setSelectedTag("all");
                  setSearchTerm("");
                  setShowFilters(true);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              },
              {
                name: "Commercial Photography",
                image: "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=600&h=400&fit=crop",
                action: () => {
                  setSelectedCategory("commercial");
                  setSelectedTag("all");
                  setSearchTerm("");
                  setShowFilters(true);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }
            ].map((category, index) => (
              <div 
                key={index} 
                className="relative overflow-hidden rounded-lg cursor-pointer group"
                onClick={category.action}
              >
                <img 
                  src={category.image} 
                  alt={category.name}
                  className="w-full aspect-[3/2] object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <h3 className="text-white font-semibold text-lg md:text-xl text-center px-4">
                    {category.name}
                  </h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Want to Be Featured in Our Gallery?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Book a photography session with us and your special moments might be featured in our gallery.
          </p>
          <Button asChild size="lg">
            <Link to="/contact">Book a Session</Link>
          </Button>
        </div>
      </section>
    </>
  );
}