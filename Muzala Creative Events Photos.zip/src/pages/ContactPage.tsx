import { Link } from "react-router-dom";
import { MapPin, Phone, Mail, Clock, Instagram, Facebook, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";
import PageBanner from "@/components/PageBanner";
import ContactForm from "@/components/ContactForm";
import SectionHeading from "@/components/SectionHeading";

export default function ContactPage() {
  return (
    <>
      <PageBanner
        title="Contact Us"
        subtitle="Get in touch to discuss your photography needs"
        backgroundImage="https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=1920&h=600&fit=crop"
      />

      {/* Contact Form Section */}
      <section className="py-20">
        <div className="container px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Left Column - Contact Info */}
            <div>
              <h2 className="text-3xl font-bold mb-6">Get in Touch</h2>
              <p className="text-muted-foreground mb-8">
                Whether you're looking to book a photography session, have questions about our services, or want to discuss a custom project, we'd love to hear from you. Fill out the form or use our contact information below to reach us.
              </p>

              <div className="space-y-6 mb-8">
                <div className="flex items-start">
                  <div className="mt-1 mr-4 p-2 bg-muted rounded-md">
                    <MapPin className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Our Studio</h3>
                    <p className="text-muted-foreground">
                      123 Photography Lane<br />
                      Creative City, ST 12345<br />
                      United States
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="mt-1 mr-4 p-2 bg-muted rounded-md">
                    <Phone className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Phone</h3>
                    <p className="text-muted-foreground">+1 (234) 567-8900</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="mt-1 mr-4 p-2 bg-muted rounded-md">
                    <Mail className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Email</h3>
                    <p className="text-muted-foreground">info@muzalacreative.com</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="mt-1 mr-4 p-2 bg-muted rounded-md">
                    <Clock className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Business Hours</h3>
                    <p className="text-muted-foreground">
                      Monday - Friday: 9:00 AM - 6:00 PM<br />
                      Saturday: 10:00 AM - 4:00 PM<br />
                      Sunday: Closed
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-3">Connect With Us</h3>
                <div className="flex space-x-4">
                  <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" 
                    className="p-2 bg-muted rounded-md hover:bg-muted/80 transition-colors">
                    <Instagram size={20} />
                  </a>
                  <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" 
                    className="p-2 bg-muted rounded-md hover:bg-muted/80 transition-colors">
                    <Facebook size={20} />
                  </a>
                  <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" 
                    className="p-2 bg-muted rounded-md hover:bg-muted/80 transition-colors">
                    <Twitter size={20} />
                  </a>
                </div>
              </div>
            </div>

            {/* Right Column - Contact Form */}
            <div className="bg-muted/30 p-8 rounded-lg">
              <h2 className="text-2xl font-bold mb-6">Send Us a Message</h2>
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-12">
        <div className="container px-4">
          <div className="aspect-[16/9] w-full rounded-lg overflow-hidden shadow-lg">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.30597735!2d-74.25986543435541!3d40.69714941680757!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2s!4v1595446965862!5m2!1sen!2s" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen={true} 
              loading="lazy"
              title="Studio Location"
            ></iframe>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Frequently Asked Questions"
            subtitle="Quick answers to common inquiries"
          />
          <div className="grid md:grid-cols-2 gap-x-12 gap-y-8 mt-12">
            {[
              {
                question: "How far in advance should I book a session?",
                answer: "We recommend booking at least 2-4 weeks in advance for portrait sessions and 3-6 months for weddings and large events to secure your preferred date."
              },
              {
                question: "What is your cancellation policy?",
                answer: "Cancellations made more than 14 days before your session receive a full refund. Cancellations within 14 days will receive a 50% refund. Rescheduling is available at no cost with 7+ days' notice."
              },
              {
                question: "How long until I receive my photos?",
                answer: "Portrait sessions are typically delivered within 1-2 weeks. Weddings and events within 3-4 weeks. Rush delivery is available for an additional fee."
              },
              {
                question: "Do you offer gift certificates?",
                answer: "Yes! We offer gift certificates for all our photography services. They make perfect gifts for weddings, anniversaries, birthdays, or any special occasion."
              }
            ].map((faq, index) => (
              <div key={index} className="mb-6">
                <h4 className="text-lg font-semibold mb-2">{faq.question}</h4>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Create Something Beautiful?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            We're excited to hear about your photography needs and discuss how we can help bring your vision to life.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg">
              <Link to="/services">Explore Our Services</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/portfolio">View Our Portfolio</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}