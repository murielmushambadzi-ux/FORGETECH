import { Link } from 'react-router-dom';
import { Camera, Users, Calendar, ShoppingBag, CheckCircle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PageBanner from '@/components/PageBanner';
import SectionHeading from '@/components/SectionHeading';
import ServiceCard from '@/components/ServiceCard';

const services = [
  {
    id: 1,
    title: "Wedding Photography",
    description: "Comprehensive coverage of your special day, from preparation to reception.",
    icon: <Camera className="h-10 w-10" />,
    image: "https://images.unsplash.com/photo-1519741497674-611481863552?w=800&h=600&fit=crop",
    link: "/services/wedding",
    features: [
      "Pre-wedding consultation",
      "Full day coverage (up to 12 hours)",
      "Two professional photographers",
      "Engagement session",
      "Online gallery with high-resolution images",
      "Custom wedding album"
    ]
  },
  {
    id: 2,
    title: "Event Coverage",
    description: "Professional photography for corporate events, parties, and special celebrations.",
    icon: <Calendar className="h-10 w-10" />,
    image: "https://images.unsplash.com/photo-1540317580384-e5d43867caa6?w=800&h=600&fit=crop",
    link: "/services/events",
    features: [
      "Corporate events and conferences",
      "Birthday and anniversary parties",
      "Award ceremonies and galas",
      "Product launches",
      "Flexible coverage options",
      "Fast turnaround time"
    ]
  },
  {
    id: 3,
    title: "Portrait Sessions",
    description: "Stunning portrait photography that captures personality and creates timeless images.",
    icon: <Users className="h-10 w-10" />,
    image: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=800&h=600&fit=crop",
    link: "/services/portraits",
    features: [
      "Individual and family portraits",
      "Professional headshots",
      "Senior portraits",
      "Maternity and newborn sessions",
      "Studio or on-location options",
      "Retouching and editing services"
    ]
  },
  {
    id: 4,
    title: "Commercial Photography",
    description: "High-quality commercial photography for brands, products, and marketing campaigns.",
    icon: <ShoppingBag className="h-10 w-10" />,
    image: "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=800&h=600&fit=crop",
    link: "/services/commercial",
    features: [
      "Product photography",
      "Real estate and architectural photos",
      "Food and restaurant photography",
      "Fashion and lifestyle shoots",
      "Brand story campaigns",
      "Digital assets for website and social media"
    ]
  }
];

export default function ServicesPage() {
  return (
    <>
      <PageBanner
        title="Our Photography Services"
        subtitle="Professional photography services tailored to your unique needs"
        backgroundImage="https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=1920&h=600&fit=crop"
      />

      {/* Services Overview */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="What We Offer"
            subtitle="Explore our wide range of professional photography services"
          />

          <div className="grid md:grid-cols-2 gap-8 mt-12">
            {services.map((service) => (
              <div key={service.id} className="border border-border rounded-lg overflow-hidden bg-background">
                <div className="aspect-video w-full overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title} 
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="text-primary mr-3">{service.icon}</div>
                    <h3 className="text-2xl font-semibold">{service.title}</h3>
                  </div>
                  <p className="text-muted-foreground mb-6">{service.description}</p>
                  <h4 className="font-medium mb-3">What's Included:</h4>
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button asChild>
                    <Link to={service.link}>
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Our Process"
            subtitle="How we work with you from start to finish"
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
            {[
              {
                step: "1",
                title: "Consultation",
                description: "We discuss your vision, requirements, and expectations to ensure we understand your needs perfectly."
              },
              {
                step: "2",
                title: "Planning",
                description: "We develop a detailed plan including locations, timing, shot list, and any specific requirements."
              },
              {
                step: "3",
                title: "Photoshoot",
                description: "Our professional photographers capture your event or session with creativity and technical excellence."
              },
              {
                step: "4",
                title: "Delivery",
                description: "We edit and deliver your beautiful photographs through a convenient online gallery."
              }
            ].map((process, index) => (
              <div key={index} className="relative">
                <div className="bg-background rounded-lg p-6 h-full shadow-sm relative z-10">
                  <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg mb-4">
                    {process.step}
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{process.title}</h3>
                  <p className="text-muted-foreground">{process.description}</p>
                </div>
                {index < 3 && (
                  <div className="hidden lg:block absolute top-1/2 right-0 w-1/2 h-0.5 bg-primary/30 z-0 translate-y-4"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="container px-4">
          <SectionHeading
            title="Frequently Asked Questions"
            subtitle="Answers to common questions about our services"
          />
          <div className="grid md:grid-cols-2 gap-x-12 gap-y-8 mt-12">
            {[
              {
                question: "How far in advance should I book?",
                answer: "We recommend booking at least 3-6 months in advance for weddings and 2-4 weeks for other sessions, but we always try to accommodate last-minute bookings when possible."
              },
              {
                question: "How many photos will I receive?",
                answer: "The number varies by service. Typically, weddings include 500-800 edited images, portrait sessions 30-50 images, and events depend on duration and size."
              },
              {
                question: "Do you offer video services?",
                answer: "Yes, we offer videography services for weddings and events, which can be added to any photography package or booked separately."
              },
              {
                question: "How long until I receive my photos?",
                answer: "Portrait sessions are typically delivered within 1-2 weeks. Weddings and events within 3-4 weeks. Rush delivery is available for an additional fee."
              },
              {
                question: "Do you travel for photoshoots?",
                answer: "Yes, we're available for travel nationwide and internationally. Travel fees apply depending on location and duration."
              },
              {
                question: "What is your payment policy?",
                answer: "We require a 50% deposit to secure your booking, with the remaining balance due one week before the event or session. We accept credit cards, bank transfers, and cash."
              }
            ].map((faq, index) => (
              <div key={index} className="mb-6">
                <h4 className="text-lg font-semibold mb-2">{faq.question}</h4>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <p className="text-muted-foreground mb-4">
              Have more questions? We're happy to help!
            </p>
            <Button asChild>
              <Link to="/contact">Contact Us</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-20 bg-secondary text-secondary-foreground">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">What Our Clients Say</h2>
            <div className="text-3xl italic mb-6">
              "Working with MUZALA CREATIVE was an absolute pleasure. The team was professional, creative, and delivered photos that exceeded our expectations. They truly captured the essence of our special day."
            </div>
            <div className="font-medium">Sarah & Michael</div>
            <div className="text-sm">Wedding Clients</div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container px-4 text-center">
          <SectionHeading
            title="Ready to Book Your Session?"
            subtitle="Contact us today to check availability and discuss your photography needs"
          />
          <Button asChild size="lg">
            <Link to="/contact">Book Now</Link>
          </Button>
        </div>
      </section>
    </>
  );
}