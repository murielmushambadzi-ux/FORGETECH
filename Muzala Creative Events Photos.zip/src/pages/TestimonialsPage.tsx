import { useState } from "react";
import { Link } from "react-router-dom";
import { Star, Quote, Camera } from "lucide-react";
import { Button } from "@/components/ui/button";
import PageBanner from "@/components/PageBanner";
import TestimonialCard from "@/components/TestimonialCard";
import SectionHeading from "@/components/SectionHeading";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Testimonial data
const testimonials = {
  weddings: [
    {
      id: 1,
      name: "Sarah & Michael",
      role: "Wedding Clients",
      quote: "MUZALA CREATIVE captured our wedding day perfectly. The photos are absolutely stunning and captured all the emotions of our special day. Alex and his team were professional, discreet, and made everyone feel comfortable in front of the camera.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1531747118685-ca8fa6e08806?w=100&h=100&fit=crop",
      date: "June 2025"
    },
    {
      id: 2,
      name: "Jessica & David",
      role: "Wedding Clients",
      quote: "We are absolutely in love with our wedding photos! MUZALA CREATIVE has an incredible eye for detail and captured moments we didn't even know happened. The candid shots especially are treasures we'll cherish forever. Worth every penny!",
      rating: 5,
      image: "https://images.unsplash.com/photo-1509512693283-8178ed23e04c?w=100&h=100&fit=crop",
      date: "May 2025"
    },
    {
      id: 3,
      name: "Emily & Thomas",
      role: "Wedding Clients",
      quote: "Working with MUZALA CREATIVE was one of the best decisions we made for our wedding. They were able to capture not just how our day looked, but how it felt. Their creative direction and professionalism were outstanding.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1522556189639-b150ed9c4330?w=100&h=100&fit=crop",
      date: "April 2025"
    },
    {
      id: 4,
      name: "Laura & Robert",
      role: "Wedding Clients",
      quote: "We were initially nervous about having cameras around all day, but Alex and his team put us at ease immediately. The result was natural, beautiful photos that perfectly captured our wedding day. Highly recommend!",
      rating: 5,
      image: "https://images.unsplash.com/photo-1548142813-c348350df52b?w=100&h=100&fit=crop",
      date: "March 2025"
    },
  ],
  events: [
    {
      id: 5,
      name: "James Wilson",
      role: "Marketing Director, TechCorp",
      quote: "MUZALA CREATIVE provided exceptional photography for our annual corporate gala. They were professional, unobtrusive, and the resulting images exceeded our expectations. We'll definitely be using them for all our future events.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
      date: "May 2025"
    },
    {
      id: 6,
      name: "Patricia Lee",
      role: "Event Coordinator",
      quote: "Working with MUZALA CREATIVE for our product launch event was fantastic. They captured every key moment beautifully, and delivered the photos with impressive turnaround time. The team was flexible, professional, and delivered exceptional work.",
      rating: 4,
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&h=100&fit=crop",
      date: "April 2025"
    },
    {
      id: 7,
      name: "Mark Thompson",
      role: "Conference Organizer",
      quote: "MUZALA CREATIVE's event photography services were outstanding. They captured both the formal presentations and candid networking moments perfectly. Their ability to work unobtrusively in a professional setting is remarkable.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
      date: "March 2025"
    },
    {
      id: 8,
      name: "Karen Davis",
      role: "Charity Gala Organizer",
      quote: "The MUZALA CREATIVE team was wonderful to work with for our annual charity gala. They understood exactly what we needed and delivered beautiful images that we've used in our marketing materials throughout the year.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
      date: "February 2025"
    },
  ],
  portraits: [
    {
      id: 9,
      name: "Emma Rodriguez",
      role: "Portrait Client",
      quote: "I've never felt so comfortable during a photoshoot. The team at MUZALA CREATIVE knew exactly how to bring out my best features and personality. The photos are beautiful and really captured my essence. Highly recommend!",
      rating: 5,
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop",
      date: "June 2025"
    },
    {
      id: 10,
      name: "John Martinez",
      role: "Professional Headshots",
      quote: "I needed new professional headshots for my business and MUZALA CREATIVE delivered exactly what I was looking for. They took the time to understand my brand and the results perfectly represent my professional identity.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100&h=100&fit=crop",
      date: "May 2025"
    },
    {
      id: 11,
      name: "The Johnson Family",
      role: "Family Portrait Clients",
      quote: "Our family portrait session with MUZALA CREATIVE was such a fun experience! They were amazing with our kids and somehow managed to get perfect shots even with our energetic 3-year-old. The photos capture our family beautifully.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1484688493527-670f98f9b195?w=100&h=100&fit=crop",
      date: "April 2025"
    },
    {
      id: 12,
      name: "Sophia Wang",
      role: "Senior Portrait Client",
      quote: "My senior portraits turned out amazing! MUZALA CREATIVE listened to what I wanted and made the whole experience enjoyable. The photos are unique and really show my personality. My friends all want to know who took my pictures!",
      rating: 5,
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
      date: "March 2025"
    },
  ],
  commercial: [
    {
      id: 13,
      name: "Daniel Clark",
      role: "Marketing Manager, LuxeStyle",
      quote: "MUZALA CREATIVE's product photography elevated our entire catalog. Their attention to detail and lighting expertise made our products look their absolute best. The images have significantly improved our online conversion rate.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=100&h=100&fit=crop",
      date: "May 2025"
    },
    {
      id: 14,
      name: "Rebecca Adams",
      role: "Real Estate Agent",
      quote: "The architectural and real estate photography from MUZALA CREATIVE has transformed my property listings. Their ability to showcase spaces in their best light has directly contributed to faster sales and higher offers.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&h=100&fit=crop",
      date: "April 2025"
    },
    {
      id: 15,
      name: "Michael Chen",
      role: "Restaurant Owner",
      quote: "The food photography from MUZALA CREATIVE perfectly captures the essence of our dishes. Since updating our menu and website with their images, we've seen a noticeable increase in orders of the featured items.",
      rating: 4,
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
      date: "March 2025"
    },
    {
      id: 16,
      name: "Lisa Morgan",
      role: "Fashion Designer",
      quote: "Working with MUZALA CREATIVE for our seasonal lookbook was an absolute pleasure. They understood our brand aesthetic perfectly and delivered images that exceeded our expectations. Our collection has never looked better.",
      rating: 5,
      image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop",
      date: "February 2025"
    },
  ],
};

export default function TestimonialsPage() {
  const [activeTab, setActiveTab] = useState("all");
  
  // Combine all testimonials for the "all" tab
  const allTestimonials = [
    ...testimonials.weddings,
    ...testimonials.events,
    ...testimonials.portraits,
    ...testimonials.commercial
  ];
  
  // Get testimonials based on active tab
  const getDisplayTestimonials = () => {
    if (activeTab === "all") return allTestimonials;
    return testimonials[activeTab as keyof typeof testimonials] || [];
  };

  return (
    <>
      <PageBanner
        title="Client Testimonials"
        subtitle="Hear what our clients have to say about their experience with MUZALA CREATIVE"
        backgroundImage="https://images.unsplash.com/photo-1560932684-5e552e2894e9?w=1920&h=600&fit=crop"
      />

      {/* Featured Testimonial */}
      <section className="py-16">
        <div className="container px-4">
          <div className="max-w-4xl mx-auto bg-secondary text-secondary-foreground p-8 md:p-12 rounded-lg relative">
            <Quote className="absolute top-6 left-6 h-12 w-12 opacity-20" />
            <div className="text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-8">What Our Clients Say</h2>
              <div className="text-xl md:text-2xl italic mb-8 relative z-10">
                "Working with MUZALA CREATIVE was an absolute dream. They captured moments I didn't even realize were happening and delivered photos that tell the story of our day perfectly. Looking at our wedding album brings all those emotions flooding back every time."
              </div>
              <div className="flex justify-center mb-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <div className="font-medium text-lg">Sarah & Michael Thompson</div>
              <div className="text-sm text-secondary-foreground/80">Wedding Clients, June 2025</div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial Categories */}
      <section className="py-12">
        <div className="container px-4">
          <SectionHeading
            title="Client Experiences"
            subtitle="Read testimonials from clients across our different photography services"
          />
          
          <Tabs defaultValue="all" className="mt-8" onValueChange={setActiveTab}>
            <div className="flex justify-center mb-8">
              <TabsList>
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="weddings">Weddings</TabsTrigger>
                <TabsTrigger value="events">Events</TabsTrigger>
                <TabsTrigger value="portraits">Portraits</TabsTrigger>
                <TabsTrigger value="commercial">Commercial</TabsTrigger>
              </TabsList>
            </div>
            
            {/* All Tabs Content */}
            <TabsContent value="all" className="mt-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {allTestimonials.map((testimonial) => (
                  <TestimonialCard
                    key={testimonial.id}
                    name={testimonial.name}
                    role={testimonial.role}
                    quote={testimonial.quote}
                    rating={testimonial.rating}
                    image={testimonial.image}
                  />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="weddings" className="mt-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {testimonials.weddings.map((testimonial) => (
                  <TestimonialCard
                    key={testimonial.id}
                    name={testimonial.name}
                    role={testimonial.role}
                    quote={testimonial.quote}
                    rating={testimonial.rating}
                    image={testimonial.image}
                  />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="events" className="mt-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {testimonials.events.map((testimonial) => (
                  <TestimonialCard
                    key={testimonial.id}
                    name={testimonial.name}
                    role={testimonial.role}
                    quote={testimonial.quote}
                    rating={testimonial.rating}
                    image={testimonial.image}
                  />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="portraits" className="mt-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {testimonials.portraits.map((testimonial) => (
                  <TestimonialCard
                    key={testimonial.id}
                    name={testimonial.name}
                    role={testimonial.role}
                    quote={testimonial.quote}
                    rating={testimonial.rating}
                    image={testimonial.image}
                  />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="commercial" className="mt-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {testimonials.commercial.map((testimonial) => (
                  <TestimonialCard
                    key={testimonial.id}
                    name={testimonial.name}
                    role={testimonial.role}
                    quote={testimonial.quote}
                    rating={testimonial.rating}
                    image={testimonial.image}
                  />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Video Testimonials Section */}
      <section className="py-16 bg-muted/30">
        <div className="container px-4">
          <SectionHeading
            title="Video Testimonials"
            subtitle="Hear directly from our clients about their photography experience"
          />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            {[
              {
                title: "Sarah & Michael's Wedding Day",
                thumbnail: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=600&h=400&fit=crop",
                client: "Sarah & Michael Thompson"
              },
              {
                title: "TechCorp Annual Conference",
                thumbnail: "https://images.unsplash.com/photo-1540317580384-e5d43867caa6?w=600&h=400&fit=crop",
                client: "James Wilson, TechCorp"
              },
              {
                title: "Rodriguez Family Portrait Session",
                thumbnail: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=600&h=400&fit=crop",
                client: "Emma Rodriguez"
              }
            ].map((video, index) => (
              <div key={index} className="relative group">
                <div className="aspect-video rounded-lg overflow-hidden">
                  <img 
                    src={video.thumbnail} 
                    alt={video.title} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-primary/90 flex items-center justify-center">
                      <div className="w-5 h-5 border-t-8 border-t-transparent border-l-8 border-l-white border-b-8 border-b-transparent ml-1"></div>
                    </div>
                  </div>
                </div>
                <h3 className="font-semibold mt-3">{video.title}</h3>
                <p className="text-sm text-muted-foreground">{video.client}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-16">
        <div className="container px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { value: "200+", label: "Happy Clients", icon: <Camera className="h-8 w-8 text-primary mx-auto mb-3" /> },
              { value: "98%", label: "Satisfaction Rate", icon: <Star className="h-8 w-8 text-primary mx-auto mb-3" /> },
              { value: "70%", label: "Repeat Clients", icon: <Quote className="h-8 w-8 text-primary mx-auto mb-3" /> },
              { value: "85%", label: "Referrals", icon: <Quote className="h-8 w-8 text-primary mx-auto mb-3" /> },
            ].map((stat, index) => (
              <div key={index} className="p-6 bg-muted/30 rounded-lg">
                {stat.icon}
                <div className="text-3xl md:text-4xl font-bold mb-2">{stat.value}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Leave Review Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Had a Great Experience?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            We'd love to hear about your experience with MUZALA CREATIVE. Leave a review or share your testimonial with us.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild variant="outline" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground/20">
              <Link to="/contact">Share Your Experience</Link>
            </Button>
            <Button asChild className="bg-white text-primary hover:bg-white/90">
              <a href="https://google.com" target="_blank" rel="noopener noreferrer">
                Leave a Google Review
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container px-4 text-center">
          <SectionHeading
            title="Ready to Create Your Own Success Story?"
            subtitle="Join our growing list of satisfied clients"
          />
          <div className="flex flex-wrap justify-center gap-4 mt-8">
            <Button asChild size="lg">
              <Link to="/contact">Book a Session</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/services">Explore Services</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}